import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';

// Pages
import { Home } from './pages/Home';
import { Events } from './pages/Events';
import { EventDetails } from './pages/EventDetails';
import { Trending } from './pages/Trending';
import { Organizations } from './pages/Organizations';
import { OrganizationDetails } from './pages/OrganizationDetails';
import { AiRecommend } from './pages/AiRecommend';
import { Teammates } from './pages/Teammates';
import { PostEvent } from './pages/PostEvent';
import { SavedEvents } from './pages/SavedEvents';
import { Profile } from './pages/Profile';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { AdminDashboard } from './pages/AdminDashboard';
import { NotFound } from './pages/NotFound';

// Scroll to top helper on route navigation
function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}

export default function App() {
  return (
    <Router>
      <ScrollToTop />
      <div className="flex flex-col min-h-screen bg-[#0f172a] text-[#f8fafc] antialiased selection:bg-[#7c3aed] selection:text-white">
        <Navbar />
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/events" element={<Events />} />
            <Route path="/events/:id" element={<EventDetails />} />
            <Route path="/trending" element={<Trending />} />
            <Route path="/organizations" element={<Organizations />} />
            <Route path="/organizations/:name" element={<OrganizationDetails />} />
            <Route path="/ai-recommend" element={<AiRecommend />} />
            <Route path="/teammates" element={<Teammates />} />
            <Route path="/post-event" element={<PostEvent />} />
            <Route path="/saved" element={<SavedEvents />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}
