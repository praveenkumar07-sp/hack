import { EventItem } from '../types';

export interface AiParsedQuery {
  rawPrompt: string;
  detectedType?: string;
  detectedCategory?: string;
  detectedMode?: string;
  detectedMinPrize?: number;
  detectedFreeOnly?: boolean;
  detectedDeadlineConstraint?: string;
  detectedKeywords: string[];
  understoodPoints: string[];
}

export interface AiMatchResult {
  event: EventItem;
  matchScore: number;
  matchReasons: string[];
}

export interface AiAnalysisResult {
  extractedCriteria: {
    audience?: string;
    category?: string;
    mode?: string;
    type?: string;
    prize?: string;
  };
  reasoning: string;
  matchedEvents: EventItem[];
}

export function parseAiQuery(query: string, allEvents: EventItem[]): AiAnalysisResult {
  const { parsedQuery, results } = parseNaturalLanguageQuery(query, allEvents);

  let audience = 'All Builders & Students';
  const qLower = query.toLowerCase();
  if (qLower.includes('ug') || qLower.includes('undergraduate') || qLower.includes('college') || qLower.includes('3rd year') || qLower.includes('student')) {
    audience = 'Undergraduate Student';
  } else if (qLower.includes('pg') || qLower.includes('postgraduate') || qLower.includes('master')) {
    audience = 'Postgraduate';
  } else if (qLower.includes('professional') || qLower.includes('working')) {
    audience = 'Professional';
  }

  const extractedCriteria = {
    audience,
    category: parsedQuery.detectedCategory || 'Artificial Intelligence',
    mode: parsedQuery.detectedMode || 'Online',
    type: parsedQuery.detectedType || 'Hackathon',
    prize: parsedQuery.detectedMinPrize ? `> ₹${parsedQuery.detectedMinPrize.toLocaleString('en-IN')}` : 'Any'
  };

  const matchedEvents = results.map(r => r.event);

  const reasoning = `Based on your request "${query}", our AI engine extracted your interest in ${extractedCriteria.category} events (${extractedCriteria.type}) suitable for ${extractedCriteria.audience}s in an ${extractedCriteria.mode} format. We identified ${matchedEvents.length} high-affinity opportunities matching your requirements and verified eligibility.`;

  return {
    extractedCriteria,
    reasoning,
    matchedEvents
  };
}

export function parseNaturalLanguageQuery(prompt: string, allEvents: EventItem[]): {
  parsedQuery: AiParsedQuery;
  results: AiMatchResult[];
} {
  const p = prompt.toLowerCase();
  const understood: string[] = [];
  const keywords: string[] = [];

  // Detect Event Type
  let detectedType: string | undefined;
  if (p.includes('hackathon') || p.includes('hack')) {
    detectedType = 'hackathon';
    understood.push('Event Type: Hackathon');
    keywords.push('hackathon');
  } else if (p.includes('conference') || p.includes('summit')) {
    detectedType = 'conference';
    understood.push('Event Type: Conference');
    keywords.push('conference');
  } else if (p.includes('workshop') || p.includes('masterclass') || p.includes('bootcamp')) {
    detectedType = 'workshop';
    understood.push('Event Type: Workshop / Masterclass');
    keywords.push('workshop');
  } else if (p.includes('certification') || p.includes('cert')) {
    detectedType = 'certification';
    understood.push('Event Type: Certification');
    keywords.push('certification');
  } else if (p.includes('fellowship') || p.includes('stipend')) {
    detectedType = 'fellowship';
    understood.push('Event Type: Fellowship');
    keywords.push('fellowship');
  } else if (p.includes('pitch') || p.includes('venture') || p.includes('startup')) {
    detectedType = 'pitch';
    understood.push('Event Type: Pitch Competition');
    keywords.push('pitch');
  } else if (p.includes('symposium') || p.includes('academic') || p.includes('paper')) {
    detectedType = 'symposium';
    understood.push('Event Type: Symposium / Academic');
    keywords.push('symposium');
  }

  // Detect Category
  let detectedCategory: string | undefined;
  if (p.includes('ai') || p.includes('artificial intelligence') || p.includes('machine learning') || p.includes('ml') || p.includes('llm') || p.includes('agent')) {
    detectedCategory = 'Artificial Intelligence';
    understood.push('Field: Artificial Intelligence & Machine Learning');
    keywords.push('AI');
  } else if (p.includes('cyber') || p.includes('security') || p.includes('ctf') || p.includes('infosec')) {
    detectedCategory = 'Cybersecurity';
    understood.push('Field: Cybersecurity & InfoSec');
    keywords.push('Cybersecurity');
  } else if (p.includes('react') || p.includes('web') || p.includes('software') || p.includes('rust') || p.includes('frontend') || p.includes('backend') || p.includes('dev')) {
    detectedCategory = 'Software Development';
    understood.push('Field: Software Development & Engineering');
    keywords.push('Software Dev');
  } else if (p.includes('cloud') || p.includes('devops') || p.includes('kubernetes') || p.includes('aws')) {
    detectedCategory = 'Cloud Computing';
    understood.push('Field: Cloud Computing & Infrastructure');
    keywords.push('Cloud');
  } else if (p.includes('data') || p.includes('analytics') || p.includes('deep learning')) {
    detectedCategory = 'Data Science';
    understood.push('Field: Data Science & Analytics');
    keywords.push('Data Science');
  } else if (p.includes('health') || p.includes('med') || p.includes('bio') || p.includes('genomic')) {
    detectedCategory = 'Healthcare';
    understood.push('Field: Healthcare & BioTech');
    keywords.push('Healthcare');
  } else if (p.includes('robot') || p.includes('drone') || p.includes('ros') || p.includes('hardware')) {
    detectedCategory = 'Robotics';
    understood.push('Field: Robotics & Autonomous Systems');
    keywords.push('Robotics');
  }

  // Detect Mode
  let detectedMode: string | undefined;
  if (p.includes('online') || p.includes('virtual') || p.includes('remote')) {
    detectedMode = 'Online';
    understood.push('Mode: Online / Virtual participation');
    keywords.push('Online');
  } else if (p.includes('offline') || p.includes('in-person') || p.includes('onsite') || p.includes('on-site')) {
    detectedMode = 'Offline';
    understood.push('Mode: In-Person / Physical venue');
    keywords.push('In-person');
  } else if (p.includes('hybrid')) {
    detectedMode = 'Hybrid';
    understood.push('Mode: Hybrid');
    keywords.push('Hybrid');
  }

  // Detect Prize minimums
  let detectedMinPrize: number | undefined;
  const prizeMatch = p.match(/(?:prize|above|over|more than|min|at least)\s*(?:₹|inr|\$)?\s*([0-9]+(?:,[0-9]+)*)/i);
  if (prizeMatch) {
    const rawVal = parseInt(prizeMatch[1].replace(/,/g, ''), 10);
    if (!isNaN(rawVal) && rawVal > 0) {
      detectedMinPrize = rawVal;
      understood.push(`Prize requirement: > ₹${rawVal.toLocaleString('en-IN')}`);
      keywords.push(`Prize > ₹${rawVal.toLocaleString('en-IN')}`);
    }
  } else if (p.includes('50000') || p.includes('50,000') || p.includes('50k')) {
    detectedMinPrize = 50000;
    understood.push('Prize requirement: > ₹50,000');
    keywords.push('Prize > ₹50,000');
  } else if (p.includes('100000') || p.includes('1,00,000') || p.includes('1 lakh') || p.includes('100k')) {
    detectedMinPrize = 100000;
    understood.push('Prize requirement: > ₹1,00,000');
    keywords.push('Prize > ₹1,00,000');
  }

  // Free only?
  let detectedFreeOnly = false;
  if (p.includes('free') || p.includes('no cost') || p.includes('zero fee')) {
    detectedFreeOnly = true;
    understood.push('Cost: 100% Free registration');
    keywords.push('Free Entry');
  }

  // Deadline
  let detectedDeadlineConstraint: string | undefined;
  if (p.includes('this month') || p.includes('urgent') || p.includes('soon') || p.includes('closing')) {
    detectedDeadlineConstraint = 'Deadlines upcoming in September - October 2026';
    understood.push('Timing: Closing soon or within this cycle');
  }

  if (understood.length === 0) {
    understood.push('General discovery across all domains and verified tech events');
  }

  const parsedQuery: AiParsedQuery = {
    rawPrompt: prompt,
    detectedType,
    detectedCategory,
    detectedMode,
    detectedMinPrize,
    detectedFreeOnly,
    detectedDeadlineConstraint,
    detectedKeywords: keywords,
    understoodPoints: understood
  };

  // Score & filter events
  const scoredResults: AiMatchResult[] = [];

  allEvents.forEach(event => {
    let score = 0;
    const matchReasons: string[] = [];

    // Category match
    if (detectedCategory) {
      if (event.category === detectedCategory) {
        score += 35;
        matchReasons.push(`Direct category match: ${event.category}`);
      } else if (event.domains.some(d => d.toLowerCase().includes(detectedCategory.toLowerCase().slice(0, 4)))) {
        score += 20;
        matchReasons.push(`Related domain knowledge in ${detectedCategory}`);
      }
    }

    // Type match
    if (detectedType) {
      if (event.type.toLowerCase() === detectedType.toLowerCase()) {
        score += 30;
        matchReasons.push(`Verified ${event.type} format`);
      }
    }

    // Mode match
    if (detectedMode) {
      if (event.mode === detectedMode || (detectedMode === 'Online' && event.mode === 'Hybrid')) {
        score += 20;
        matchReasons.push(`Accessible via ${event.mode} format`);
      }
    }

    // Prize match
    if (detectedMinPrize) {
      if (event.prizeAmount >= detectedMinPrize) {
        score += 25;
        matchReasons.push(`Prize pool requirement exceeded (₹${event.prizeAmount.toLocaleString('en-IN')})`);
      }
    }

    // Free match
    if (detectedFreeOnly) {
      if (event.costType === 'free') {
        score += 15;
        matchReasons.push('100% Free registration verified');
      }
    }

    // Keyword matching in tags / description
    const textCorpus = `${event.title} ${event.description} ${event.tags.join(' ')} ${event.domains.join(' ')}`.toLowerCase();
    keywords.forEach(kw => {
      if (textCorpus.includes(kw.toLowerCase())) {
        score += 10;
        if (!matchReasons.some(r => r.includes(kw))) {
          matchReasons.push(`Mentions relevant topics: "${kw}"`);
        }
      }
    });

    // If query was generic or broad, ensure a baseline score
    if (!detectedType && !detectedCategory && !detectedMode && !detectedMinPrize) {
      score = event.featured ? 50 : 30;
      matchReasons.push('Recommended based on high engagement in community');
    }

    if (score >= 20 || (!detectedType && !detectedCategory)) {
      scoredResults.push({
        event,
        matchScore: score,
        matchReasons: matchReasons.slice(0, 4)
      });
    }
  });

  scoredResults.sort((a, b) => b.matchScore - a.matchScore);

  return {
    parsedQuery,
    results: scoredResults.slice(0, 9)
  };
}
