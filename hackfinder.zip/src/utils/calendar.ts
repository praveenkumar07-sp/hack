import { EventItem } from '../types';

/**
 * Formats a Date object or date string into standard ICS format YYYYMMDDTHHmmssZ
 */
function formatDateToICS(dateStr: string, isEnd = false): string {
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) {
    const fallback = new Date();
    return fallback.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
  }
  if (isEnd) {
    // End of day
    d.setHours(23, 59, 59);
  } else {
    // Start of day
    d.setHours(9, 0, 0);
  }
  return d.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
}

/**
 * Generates an iCalendar (.ics) format file string and prompts download in the browser.
 */
export function downloadEventICS(event: EventItem): void {
  const dtStart = formatDateToICS(event.startDate, false);
  const dtEnd = formatDateToICS(event.endDate, true);
  const now = new Date().toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';

  const summary = event.title.replace(/[,;\\]/g, ' ');
  const description = `${event.description}\n\nOrganization: ${event.organization}\nPrize: ${event.currency} ${event.prizeAmount}\nCategory: ${event.category}\nRegister at: ${event.registrationUrl || 'https://hackfinder.dev'}`.replace(/\n/g, '\\n');
  const location = event.mode === 'Online' ? 'Online / Virtual' : `${event.city ? `${event.city}, ` : ''}${event.country}`;
  const uid = `hackfinder-${event.id}-${Date.now()}@hackfinder.dev`;

  const icsContent = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//HackFinder//Event Discovery Platform//EN',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
    'BEGIN:VEVENT',
    `UID:${uid}`,
    `DTSTAMP:${now}`,
    `DTSTART:${dtStart}`,
    `DTEND:${dtEnd}`,
    `SUMMARY:${summary}`,
    `DESCRIPTION:${description}`,
    `LOCATION:${location}`,
    `STATUS:CONFIRMED`,
    `URL:${event.registrationUrl || 'https://hackfinder.dev'}`,
    'END:VEVENT',
    'END:VCALENDAR'
  ].join('\r\n');

  const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
  const link = document.createElement('a');
  link.href = window.URL.createObjectURL(blob);
  const cleanTitle = event.title.toLowerCase().replace(/[^a-z0-9]/g, '-').slice(0, 30);
  link.setAttribute('download', `hackfinder-${cleanTitle}.ics`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
