import { EventItem, TeammateRequest, UserProfile } from '../types';
import { INITIAL_EVENTS, INITIAL_TEAMMATES, INITIAL_USER_PROFILE } from '../data/events';

const STORAGE_KEYS = {
  SAVED_EVENTS: 'hackfinder_saved_events',
  ALL_EVENTS: 'hackfinder_all_events',
  POSTED_EVENTS: 'hackfinder_posted_events',
  TEAM_REQUESTS: 'hackfinder_team_requests',
  USER_PROFILE: 'hackfinder_user_profile',
  IS_LOGGED_IN: 'hackfinder_is_logged_in'
};

export function getSavedEventIds(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SAVED_EVENTS);
    if (!raw) {
      // Seed with sample saved events for realistic initial prototype experience
      const defaultSaved = ['1', '2', '7'];
      localStorage.setItem(STORAGE_KEYS.SAVED_EVENTS, JSON.stringify(defaultSaved));
      return defaultSaved;
    }
    return JSON.parse(raw);
  } catch {
    return ['1', '2'];
  }
}

export function toggleSaveEventId(id: string): { isSaved: boolean; list: string[] } {
  const current = getSavedEventIds();
  const exists = current.includes(id);
  const updated = exists ? current.filter(item => item !== id) : [...current, id];
  try {
    localStorage.setItem(STORAGE_KEYS.SAVED_EVENTS, JSON.stringify(updated));
    window.dispatchEvent(new Event('storage'));
  } catch (err) {
    console.error('Failed to save to localStorage', err);
  }
  return { isSaved: !exists, list: updated };
}

export function clearAllSavedEvents(): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SAVED_EVENTS, JSON.stringify([]));
    window.dispatchEvent(new Event('storage'));
  } catch (err) {
    console.error('Failed to clear saved events', err);
  }
}

export function isEventSaved(id: string): boolean {
  return getSavedEventIds().includes(id);
}

export function getAllEvents(): EventItem[] {
  try {
    const rawAll = localStorage.getItem(STORAGE_KEYS.ALL_EVENTS);
    if (rawAll) {
      return JSON.parse(rawAll);
    }
    const rawPosted = localStorage.getItem(STORAGE_KEYS.POSTED_EVENTS);
    const posted: EventItem[] = rawPosted ? JSON.parse(rawPosted) : [];
    const combined = [...posted, ...INITIAL_EVENTS];
    localStorage.setItem(STORAGE_KEYS.ALL_EVENTS, JSON.stringify(combined));
    return combined;
  } catch {
    return INITIAL_EVENTS;
  }
}

export function saveAllEvents(events: EventItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.ALL_EVENTS, JSON.stringify(events));
  } catch (err) {
    console.error('Failed to save events', err);
  }
}

export function resetDefaultEvents(): EventItem[] {
  try {
    localStorage.setItem(STORAGE_KEYS.ALL_EVENTS, JSON.stringify(INITIAL_EVENTS));
    localStorage.removeItem(STORAGE_KEYS.POSTED_EVENTS);
  } catch (err) {
    console.error('Failed to reset events', err);
  }
  return INITIAL_EVENTS;
}

export function addPostedEvent(event: EventItem): void {
  try {
    const current = getAllEvents();
    const updated = [event, ...current];
    saveAllEvents(updated);
  } catch (err) {
    console.error('Failed to store posted event', err);
  }
}

export const addEvent = addPostedEvent;

export function getAllTeammates(): TeammateRequest[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TEAM_REQUESTS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.TEAM_REQUESTS, JSON.stringify(INITIAL_TEAMMATES));
      return INITIAL_TEAMMATES;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_TEAMMATES;
  }
}

export const getTeammateRequests = getAllTeammates;

export function addTeammateRequest(req: TeammateRequest): void {
  try {
    const current = getAllTeammates();
    const updated = [req, ...current];
    localStorage.setItem(STORAGE_KEYS.TEAM_REQUESTS, JSON.stringify(updated));
  } catch (err) {
    console.error('Failed to save teammate request', err);
  }
}

export const saveTeammateRequest = addTeammateRequest;

export function getUserProfile(): UserProfile {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USER_PROFILE);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(INITIAL_USER_PROFILE));
      return INITIAL_USER_PROFILE;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_USER_PROFILE;
  }
}

export function updateUserProfile(profile: Partial<UserProfile>): UserProfile {
  const current = getUserProfile();
  const updated = { ...current, ...profile };
  try {
    localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(updated));
  } catch (err) {
    console.error('Failed to update user profile', err);
  }
  return updated;
}

export const saveUserProfile = updateUserProfile;

export function isUserAuthenticated(): boolean {
  try {
    return localStorage.getItem(STORAGE_KEYS.IS_LOGGED_IN) === 'true';
  } catch {
    return false;
  }
}

export function setUserAuthenticated(status: boolean): void {
  try {
    localStorage.setItem(STORAGE_KEYS.IS_LOGGED_IN, status ? 'true' : 'false');
  } catch (err) {
    console.error('Failed to set auth status', err);
  }
}
