import { EventItem } from '../types';

export type EventStatus =
  | 'Closing Soon'
  | 'Registration Open'
  | 'Registration Closed'
  | 'Live'
  | 'Upcoming'
  | 'Completed';

/**
 * Calculates dynamic event status and days left based on registrationDeadline and event dates.
 * Current mock anchor date: Sep 16, 2026
 */
export function getEventStatus(event: EventItem): { status: EventStatus; daysLeft: number; label: string; isClosingSoon: boolean } {
  // Reference date aligned with app context (2026-09-16)
  const now = new Date('2026-09-16T00:00:00Z');
  const deadline = new Date(`${event.registrationDeadline}T23:59:59Z`);
  const start = new Date(`${event.startDate}T00:00:00Z`);
  const end = new Date(`${event.endDate}T23:59:59Z`);

  const diffTime = deadline.getTime() - now.getTime();
  const daysLeft = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (now > end) {
    return { status: 'Completed', daysLeft: 0, label: 'Completed', isClosingSoon: false };
  }

  if (now >= start && now <= end) {
    return { status: 'Live', daysLeft: 0, label: 'Live Now', isClosingSoon: false };
  }

  if (daysLeft < 0) {
    return { status: 'Registration Closed', daysLeft: 0, label: 'Registration Closed', isClosingSoon: false };
  }

  if (daysLeft <= 7) {
    return {
      status: 'Closing Soon',
      daysLeft,
      label: `${daysLeft === 0 ? 'Last Day' : `${daysLeft} DAYS LEFT`}`,
      isClosingSoon: true
    };
  }

  return { status: 'Registration Open', daysLeft, label: 'Registration Open', isClosingSoon: false };
}

export interface FilterOptions {
  search?: string;
  types?: string[];
  modes?: string[];
  categories?: string[];
  audience?: string[];
  costs?: string[];
  minPrize?: number;
  maxPrize?: number;
  closingSoonOnly?: boolean;
  featuredOnly?: boolean;
  trendingOnly?: boolean;
  sortBy?: 'newest' | 'deadline' | 'prize' | 'popularity';
}

export function filterEvents(events: EventItem[], filters: FilterOptions): EventItem[] {
  return events.filter(event => {
    // 1. Search Query
    if (filters.search && filters.search.trim() !== '') {
      const q = filters.search.toLowerCase().trim();
      const matchTitle = event.title.toLowerCase().includes(q);
      const matchOrg = event.organization.toLowerCase().includes(q);
      const matchCat = event.category.toLowerCase().includes(q);
      const matchDesc = event.description.toLowerCase().includes(q);
      const matchDomains = event.domains.some(d => d.toLowerCase().includes(q));
      const matchTags = event.tags.some(t => t.toLowerCase().includes(q));
      const matchTracks = event.tracks.some(tr => tr.toLowerCase().includes(q));
      const matchLocation = event.city.toLowerCase().includes(q) || event.country.toLowerCase().includes(q);

      if (!matchTitle && !matchOrg && !matchCat && !matchDesc && !matchDomains && !matchTags && !matchTracks && !matchLocation) {
        return false;
      }
    }

    // 2. Event Types
    if (filters.types && filters.types.length > 0) {
      if (!filters.types.map(t => t.toLowerCase()).includes(event.type.toLowerCase())) {
        return false;
      }
    }

    // 3. Modes (Online, Offline, Hybrid)
    if (filters.modes && filters.modes.length > 0) {
      if (!filters.modes.includes(event.mode)) {
        return false;
      }
    }

    // 4. Categories
    if (filters.categories && filters.categories.length > 0) {
      if (!filters.categories.includes(event.category)) {
        return false;
      }
    }

    // 5. Audience Level
    if (filters.audience && filters.audience.length > 0) {
      if (!filters.audience.includes(event.audienceLevel) && event.audienceLevel !== 'Open') {
        return false;
      }
    }

    // 6. Cost Type
    if (filters.costs && filters.costs.length > 0) {
      if (!filters.costs.map(c => c.toLowerCase()).includes(event.costType.toLowerCase())) {
        return false;
      }
    }

    // 7. Prize Range
    if (filters.minPrize !== undefined && event.prizeAmount < filters.minPrize) {
      return false;
    }
    if (filters.maxPrize !== undefined && filters.maxPrize > 0 && event.prizeAmount > filters.maxPrize) {
      return false;
    }

    // 8. Closing Soon flag
    if (filters.closingSoonOnly) {
      const { isClosingSoon } = getEventStatus(event);
      if (!isClosingSoon) return false;
    }

    // 9. Featured Only
    if (filters.featuredOnly && !event.featured) {
      return false;
    }

    // 10. Trending Only
    if (filters.trendingOnly && !event.trending) {
      return false;
    }

    return true;
  }).sort((a, b) => {
    const sortBy = filters.sortBy || 'popularity';

    if (sortBy === 'deadline') {
      return new Date(a.registrationDeadline).getTime() - new Date(b.registrationDeadline).getTime();
    }
    if (sortBy === 'prize') {
      return b.prizeAmount - a.prizeAmount;
    }
    if (sortBy === 'newest') {
      return new Date(b.startDate).getTime() - new Date(a.startDate).getTime();
    }
    // popularity (default)
    const popA = (a.viewsCount || 0) + (a.participantsCount || 0) * 2;
    const popB = (b.viewsCount || 0) + (b.participantsCount || 0) * 2;
    return popB - popA;
  });
}

export function formatPrize(amount: number, currency = 'INR'): string {
  if (!amount || amount === 0) return 'Free Entry';
  if (currency === 'INR') {
    if (amount >= 100000) {
      const lakhs = (amount / 100000).toFixed(amount % 100000 === 0 ? 0 : 1);
      return `₹${lakhs} Lakh`;
    }
    return `₹${amount.toLocaleString('en-IN')}`;
  }
  return `$${amount.toLocaleString()}`;
}
