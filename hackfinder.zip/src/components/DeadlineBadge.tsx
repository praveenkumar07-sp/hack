import React from 'react';
import { Clock, AlertTriangle, CheckCircle2, Lock } from 'lucide-react';
import { EventItem } from '../types';
import { getEventStatus } from '../utils/filters';

interface DeadlineBadgeProps {
  event: EventItem;
  className?: string;
  showIcon?: boolean;
}

export const DeadlineBadge: React.FC<DeadlineBadgeProps> = ({
  event,
  className = '',
  showIcon = true
}) => {
  const { status, label, isClosingSoon } = getEventStatus(event);

  if (isClosingSoon) {
    return (
      <span
        className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse ${className}`}
      >
        {showIcon && <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />}
        {label}
      </span>
    );
  }

  if (status === 'Registration Closed') {
    return (
      <span
        className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-800/80 text-slate-400 border border-slate-700 ${className}`}
      >
        {showIcon && <Lock className="w-3 h-3 text-slate-500" />}
        Closed
      </span>
    );
  }

  if (status === 'Live') {
    return (
      <span
        className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 ${className}`}
      >
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
        Live Now
      </span>
    );
  }

  return (
    <span
      className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-[#1e293b] text-slate-300 border border-[#334155] ${className}`}
    >
      {showIcon && <Clock className="w-3 h-3 text-cyan-400" />}
      <span>Deadline {new Date(event.registrationDeadline).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
    </span>
  );
};
