import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Calendar,
  MapPin,
  Trophy,
  CheckCircle,
  Flame,
  Star,
  Bookmark,
  ExternalLink,
  ArrowRight,
  Globe
} from 'lucide-react';
import { EventItem } from '../types';
import { DeadlineBadge } from './DeadlineBadge';
import { Badge } from './Badge';
import { formatPrize } from '../utils/filters';
import { isEventSaved, toggleSaveEventId } from '../utils/storage';

interface EventCardProps {
  event: EventItem;
  onSaveToggle?: (eventId: string, isSaved: boolean) => void;
  showSaveAnimation?: boolean;
}

export const EventCard: React.FC<EventCardProps> = ({ event, onSaveToggle }) => {
  const [saved, setSaved] = useState(() => isEventSaved(event.id));

  const handleSave = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const { isSaved } = toggleSaveEventId(event.id);
    setSaved(isSaved);
    if (onSaveToggle) {
      onSaveToggle(event.id, isSaved);
    }
  };

  const formattedDate = () => {
    const s = new Date(event.startDate);
    const e = new Date(event.endDate);
    const sMonth = s.toLocaleDateString('en-US', { month: 'short' });
    const sDay = s.getDate();
    const eDay = e.getDate();
    const year = s.getFullYear();
    if (s.toDateString() === e.toDateString()) {
      return `${sMonth} ${sDay}, ${year}`;
    }
    return `${sMonth} ${sDay} – ${eDay}, ${year}`;
  };

  const getModeIcon = () => {
    if (event.mode === 'Online') return <Globe className="w-3.5 h-3.5 text-cyan-400" />;
    return <MapPin className="w-3.5 h-3.5 text-rose-400" />;
  };

  return (
    <div className="group relative flex flex-col h-full rounded-2xl bg-[#172033]/90 border border-[#334155] overflow-hidden transition-all duration-300 hover:-translate-y-1.5 hover:border-[#7c3aed]/60 hover:shadow-xl hover:shadow-purple-900/20">
      
      {/* Banner Image Container */}
      <div className="relative h-44 w-full overflow-hidden bg-slate-900">
        <img
          src={event.image}
          alt={event.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#172033] via-[#172033]/30 to-black/40" />

        {/* Top Badges (Type, Featured, Trending) */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2 z-10">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="px-2.5 py-0.5 rounded-md text-[11px] font-extrabold tracking-wider uppercase bg-[#7c3aed] text-white shadow-md">
              {event.type}
            </span>
            {event.featured && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-bold bg-amber-500/90 text-slate-950 shadow-md">
                <Star className="w-3 h-3 fill-current" />
                FEATURED
              </span>
            )}
            {event.trending && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-bold bg-rose-500/90 text-white shadow-md">
                <Flame className="w-3 h-3 fill-current" />
                TRENDING
              </span>
            )}
          </div>

          {/* Bookmark / Save Button */}
          <button
            onClick={handleSave}
            className={`p-2 rounded-xl backdrop-blur-md transition-all active:scale-90 shadow-md ${
              saved
                ? 'bg-[#7c3aed] text-white'
                : 'bg-black/50 text-slate-300 hover:text-white hover:bg-black/70'
            }`}
            title={saved ? 'Remove from saved' : 'Save opportunity'}
            aria-label="Save event"
          >
            <Bookmark className={`w-4 h-4 ${saved ? 'fill-current' : ''}`} />
          </button>
        </div>

        {/* Bottom Banner Info (Category & Mode) */}
        <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-xs text-slate-300 z-10">
          <span className="font-semibold text-cyan-300 bg-black/40 px-2 py-0.5 rounded-md backdrop-blur-sm">
            {event.category}
          </span>
          <span className="inline-flex items-center gap-1 bg-black/40 px-2 py-0.5 rounded-md backdrop-blur-sm">
            {getModeIcon()}
            <span>{event.mode === 'Online' ? 'Online' : `${event.city || 'In-Person'}, ${event.country}`}</span>
          </span>
        </div>
      </div>

      {/* Card Body */}
      <div className="flex flex-col flex-1 p-4 sm:p-5">
        
        {/* Title */}
        <Link to={`/events/${event.id}`} className="group-hover:text-[#a78bfa] transition-colors">
          <h3 className="text-base sm:text-lg font-bold text-white line-clamp-1 leading-snug mb-1">
            {event.title}
          </h3>
        </Link>

        {/* Organization with Verified Badge */}
        <div className="flex items-center gap-1.5 text-xs text-[#94a3b8] mb-3">
          <Link
            to={`/organizations/${encodeURIComponent(event.organization.toLowerCase().replace(/\s+/g, '-'))}`}
            className="hover:text-cyan-400 transition-colors font-medium truncate max-w-[200px]"
          >
            {event.organization}
          </Link>
          {event.verified && (
            <CheckCircle className="w-3.5 h-3.5 text-cyan-400 shrink-0" title="Verified Organization" />
          )}
        </div>

        {/* Brief Description */}
        <p className="text-xs text-[#94a3b8] line-clamp-2 leading-relaxed mb-4">
          {event.description}
        </p>

        {/* Tags / Domains Pills */}
        <div className="flex items-center gap-1.5 flex-wrap mb-4">
          {event.domains.slice(0, 3).map((domain) => (
            <span
              key={domain}
              className="text-[11px] px-2 py-0.5 rounded-md bg-[#1e293b] text-slate-300 border border-[#334155]"
            >
              {domain}
            </span>
          ))}
          {event.tags && event.tags.length > 0 && (
            <span className="text-[11px] px-2 py-0.5 rounded-md bg-[#7c3aed]/10 text-purple-300 border border-[#7c3aed]/30">
              #{event.tags[0]}
            </span>
          )}
        </div>

        {/* Metrics Row: Prize & Deadline */}
        <div className="mt-auto pt-3 border-t border-[#334155]/80 flex items-center justify-between gap-2 text-xs mb-4">
          <div className="flex items-center gap-1.5 text-[#f8fafc] font-bold">
            <Trophy className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="text-amber-300 font-extrabold">
              {formatPrize(event.prizeAmount, event.currency)}
            </span>
          </div>
          <DeadlineBadge event={event} />
        </div>

        {/* Date Row & CTA */}
        <div className="flex items-center justify-between gap-2 pt-1">
          <div className="flex items-center gap-1.5 text-xs text-[#94a3b8]">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <span>{formattedDate()}</span>
          </div>

          <Link
            to={`/events/${event.id}`}
            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#7c3aed]/15 hover:bg-[#7c3aed] text-[#c084fc] hover:text-white text-xs font-semibold border border-[#7c3aed]/40 transition-all duration-200 group-hover:shadow-md group-hover:shadow-purple-600/20"
          >
            <span>View Details</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
          </Link>
        </div>

      </div>
    </div>
  );
};
