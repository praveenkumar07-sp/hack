import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, ArrowRight, Calendar, MapPin } from 'lucide-react';
import { Organization } from '../types';

interface OrganizationCardProps {
  org: Organization;
}

export const OrganizationCard: React.FC<OrganizationCardProps> = ({ org }) => {
  return (
    <div className="flex flex-col h-full rounded-2xl bg-[#172033]/80 border border-[#334155] p-6 hover:border-[#7c3aed]/50 hover:shadow-xl hover:shadow-purple-950/20 transition-all duration-300 group">
      <div className="flex items-start justify-between gap-4 mb-4">
        <div className="w-14 h-14 rounded-2xl bg-slate-900 border border-[#334155] overflow-hidden p-1 flex items-center justify-center shrink-0">
          <img
            src={org.logo}
            alt={org.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover rounded-xl group-hover:scale-105 transition-transform"
          />
        </div>
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-[#1e293b] text-cyan-300 border border-[#334155]">
          <Calendar className="w-3 h-3 text-cyan-400" />
          {org.eventsCount} Events
        </span>
      </div>

      <div className="flex items-center gap-1.5 mb-1.5">
        <h3 className="text-base font-bold text-white group-hover:text-[#a78bfa] transition-colors truncate">
          {org.name}
        </h3>
        {org.verified && (
          <CheckCircle className="w-4 h-4 text-cyan-400 shrink-0" title="Verified Organization" />
        )}
      </div>

      <p className="text-xs text-[#94a3b8] line-clamp-2 leading-relaxed mb-4">
        {org.description}
      </p>

      {/* Domains */}
      <div className="flex items-center gap-1.5 flex-wrap mb-4">
        {org.domains.map((dom) => (
          <span
            key={dom}
            className="text-[11px] px-2 py-0.5 rounded-md bg-[#1e293b] text-slate-300 border border-[#334155]"
          >
            {dom}
          </span>
        ))}
      </div>

      {/* Location info */}
      <div className="flex items-center gap-1.5 text-xs text-[#64748b] mb-5 mt-auto">
        <MapPin className="w-3.5 h-3.5" />
        <span className="truncate">{org.location}</span>
      </div>

      {/* Action CTA */}
      <Link
        to={`/organizations/${org.slug}`}
        className="w-full py-2.5 px-4 rounded-xl bg-[#1e293b] hover:bg-[#7c3aed] text-slate-200 hover:text-white text-xs font-semibold border border-[#334155] hover:border-[#7c3aed] transition-all flex items-center justify-center gap-2 group-hover:shadow-md"
      >
        <span>Explore Events</span>
        <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
      </Link>
    </div>
  );
};
