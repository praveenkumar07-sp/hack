import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  Compass,
  Flame,
  Building2,
  Sparkles,
  Users,
  Bookmark,
  User,
  Menu,
  X,
  PlusCircle,
  ShieldCheck,
  Search
} from 'lucide-react';
import { getSavedEventIds } from '../utils/storage';

export const Navbar: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [savedCount, setSavedCount] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [isScrolled, setIsScrolled] = useState(false);

  // Sync saved count whenever location changes or storage event fires
  const syncSavedCount = () => {
    setSavedCount(getSavedEventIds().length);
  };

  useEffect(() => {
    syncSavedCount();
    const handleStorage = () => syncSavedCount();
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, [location.pathname]);

  // Handle scroll styling
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/events?search=${encodeURIComponent(searchQuery.trim())}`);
      setSearchQuery('');
      setMobileMenuOpen(false);
    }
  };

  const navLinks = [
    { name: 'Explore', path: '/events', icon: Compass },
    { name: 'Trending', path: '/trending', icon: Flame },
    { name: 'Organizations', path: '/organizations', icon: Building2 },
    { name: 'AI Recommend', path: '/ai-recommend', icon: Sparkles, highlight: true },
    { name: 'Teammates', path: '/teammates', icon: Users },
  ];

  const isActive = (path: string) => {
    if (path === '/events' && location.pathname === '/events') return true;
    if (path !== '/' && location.pathname.startsWith(path)) return true;
    return false;
  };

  return (
    <header
      className={`sticky top-0 z-40 w-full transition-all duration-200 ${
        isScrolled
          ? 'bg-[#0f172a]/90 backdrop-blur-md border-b border-[#334155]/80 shadow-lg shadow-black/20'
          : 'bg-[#0f172a]/70 backdrop-blur-sm border-b border-[#334155]/40'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Logo & Brand */}
          <Link to="/" className="flex items-center gap-3 shrink-0 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#7c3aed] to-[#06b6d4] flex items-center justify-center shadow-md shadow-purple-600/30 group-hover:scale-105 transition-transform">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-extrabold tracking-tight text-[#f8fafc] group-hover:text-white flex items-center gap-1.5">
                Hack<span className="text-gradient">Finder</span>
              </span>
              <span className="text-[10px] text-[#94a3b8] -mt-1 hidden sm:block tracking-wide">
                Breakthrough Discovery
              </span>
            </div>
          </Link>

          {/* Quick Search input (Desktop) */}
          <form onSubmit={handleSearchSubmit} className="hidden lg:flex items-center relative max-w-xs w-full">
            <Search className="w-4 h-4 absolute left-3 text-[#94a3b8]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search hackathons, skills..."
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl bg-[#172033] border border-[#334155] text-[#f8fafc] placeholder-[#94a3b8] focus:outline-none focus:border-[#7c3aed] focus:ring-1 focus:ring-[#7c3aed] transition-all"
            />
          </form>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-1.5 text-sm font-medium">
            {navLinks.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.path);
              return (
                <Link
                  key={item.name}
                  to={item.path}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                    active
                      ? 'text-[#f8fafc] bg-[#1e293b] font-semibold border border-[#334155]'
                      : 'text-[#94a3b8] hover:text-[#f8fafc] hover:bg-[#172033]'
                  } ${item.highlight ? 'text-cyan-400 hover:text-cyan-300' : ''}`}
                >
                  <Icon className={`w-4 h-4 ${item.highlight ? 'text-cyan-400' : ''}`} />
                  <span>{item.name}</span>
                  {item.highlight && (
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Right Action Icons (Saved, Profile, Post Event) */}
          <div className="hidden sm:flex items-center gap-2">
            <Link
              to="/post-event"
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-[#1e293b] hover:bg-[#334155] text-slate-200 border border-[#334155] transition-colors"
              title="Post an Event"
            >
              <PlusCircle className="w-4 h-4 text-[#a78bfa]" />
              <span className="hidden xl:inline">Post Event</span>
            </Link>

            <Link
              to="/saved"
              className={`relative p-2 rounded-lg transition-colors ${
                location.pathname === '/saved'
                  ? 'bg-[#1e293b] text-[#c084fc] border border-[#7c3aed]/40'
                  : 'text-[#94a3b8] hover:text-[#f8fafc] hover:bg-[#172033]'
              }`}
              title="Saved Events"
            >
              <Bookmark className="w-5 h-5" />
              {savedCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 bg-[#7c3aed] text-white text-[10px] font-bold rounded-full flex items-center justify-center shadow-md">
                  {savedCount}
                </span>
              )}
            </Link>

            <Link
              to="/profile"
              className={`p-1.5 rounded-lg border transition-all ${
                location.pathname === '/profile'
                  ? 'border-[#7c3aed] bg-[#7c3aed]/20 text-white'
                  : 'border-[#334155] bg-[#172033] text-[#94a3b8] hover:text-[#f8fafc] hover:border-slate-500'
              }`}
              title="Your Profile"
            >
              <User className="w-5 h-5" />
            </Link>

            <Link
              to="/admin"
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-[#172033] transition-colors"
              title="Admin Dashboard"
            >
              <ShieldCheck className="w-5 h-5" />
            </Link>
          </div>

          {/* Mobile Hamburger Toggle */}
          <div className="flex sm:hidden items-center gap-2">
            <Link
              to="/saved"
              className="relative p-2 text-[#94a3b8] hover:text-[#f8fafc]"
              title="Saved Events"
            >
              <Bookmark className="w-5 h-5" />
              {savedCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#7c3aed] text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                  {savedCount}
                </span>
              )}
            </Link>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-[#94a3b8] hover:text-[#f8fafc] hover:bg-[#172033] focus:outline-none"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer Navigation Menu */}
      {mobileMenuOpen && (
        <div className="sm:hidden bg-[#172033] border-b border-[#334155] px-4 pt-3 pb-6 space-y-3 animate-in slide-in-from-top duration-200">
          <form onSubmit={handleSearchSubmit} className="relative w-full mb-3">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-[#94a3b8]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search hackathons, domains..."
              className="w-full pl-9 pr-3 py-2 text-sm rounded-xl bg-[#0f172a] border border-[#334155] text-[#f8fafc] placeholder-[#94a3b8] focus:outline-none focus:border-[#7c3aed]"
            />
          </form>

          <div className="grid grid-cols-1 gap-1">
            {navLinks.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.path);
              return (
                <Link
                  key={item.name}
                  to={item.path}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium ${
                    active
                      ? 'bg-[#1e293b] text-[#c084fc] font-semibold border border-[#334155]'
                      : 'text-[#94a3b8] hover:text-[#f8fafc] hover:bg-[#0f172a]'
                  }`}
                >
                  <Icon className="w-5 h-5 text-[#a78bfa]" />
                  <span>{item.name}</span>
                </Link>
              );
            })}
          </div>

          <div className="pt-3 border-t border-[#334155] grid grid-cols-2 gap-2">
            <Link
              to="/post-event"
              className="flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-[#1e293b] border border-[#334155] text-xs font-semibold text-slate-200"
            >
              <PlusCircle className="w-4 h-4 text-[#a78bfa]" />
              Post Event
            </Link>
            <Link
              to="/profile"
              className="flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-[#7c3aed] text-white text-xs font-semibold"
            >
              <User className="w-4 h-4" />
              Profile
            </Link>
          </div>
        </div>
      )}
    </header>
  );
};
