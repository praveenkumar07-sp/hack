import React from 'react';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'surface' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  icon?: React.ReactNode;
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'surface',
  size = 'sm',
  icon,
  className = ''
}) => {
  const variantStyles = {
    primary: 'bg-[#7c3aed]/15 text-[#c084fc] border border-[#7c3aed]/30',
    secondary: 'bg-[#06b6d4]/15 text-[#38bdf8] border border-[#06b6d4]/30',
    success: 'bg-[#22c55e]/15 text-[#4ade80] border border-[#22c55e]/30',
    warning: 'bg-[#f59e0b]/15 text-[#fbbf24] border border-[#f59e0b]/30',
    danger: 'bg-[#ef4444]/15 text-[#f87171] border border-[#ef4444]/30',
    surface: 'bg-[#1e293b] text-[#94a3b8] border border-[#334155]',
    outline: 'bg-transparent text-[#94a3b8] border border-[#334155]'
  };

  const sizeStyles = {
    sm: 'text-xs px-2.5 py-0.5 rounded-full font-medium',
    md: 'text-xs px-3 py-1 rounded-full font-semibold',
    lg: 'text-sm px-3.5 py-1.5 rounded-full font-semibold'
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 whitespace-nowrap transition-colors ${variantStyles[variant]} ${sizeStyles[size]} ${className}`}
    >
      {icon && <span className="shrink-0">{icon}</span>}
      {children}
    </span>
  );
};
