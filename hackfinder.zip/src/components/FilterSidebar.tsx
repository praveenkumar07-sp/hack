import React, { useState } from 'react';
import { Filter, X, RotateCcw, ChevronDown, ChevronUp } from 'lucide-react';
import { FilterOptions } from '../utils/filters';
import { EVENT_CATEGORIES } from '../data/events';

interface FilterSidebarProps {
  filters: FilterOptions;
  onChange: (newFilters: FilterOptions) => void;
  onClear: () => void;
  isMobileDrawer?: boolean;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
  totalCount?: number;
}

const EVENT_TYPES = [
  { id: 'hackathon', label: 'Hackathon' },
  { id: 'conference', label: 'Conference' },
  { id: 'symposium', label: 'Symposium' },
  { id: 'workshop', label: 'Workshop' },
  { id: 'certification', label: 'Certification' },
  { id: 'fellowship', label: 'Fellowship' },
  { id: 'pitch', label: 'Pitch' },
];

const MODES = [
  { id: 'Online', label: 'Online' },
  { id: 'Offline', label: 'Offline' },
  { id: 'Hybrid', label: 'Hybrid' },
];

const AUDIENCES = [
  { id: 'School', label: 'School' },
  { id: 'UG', label: 'Undergraduate (UG)' },
  { id: 'PG', label: 'Postgraduate (PG)' },
  { id: 'Professionals', label: 'Professionals' },
  { id: 'Open', label: 'Open to All' },
];

const COSTS = [
  { id: 'free', label: 'Free' },
  { id: 'paid', label: 'Paid' },
  { id: 'scholarship', label: 'Scholarship' },
];

export const FilterSidebar: React.FC<FilterSidebarProps> = ({
  filters,
  onChange,
  onClear,
  isMobileDrawer = false,
  isOpenMobile = false,
  onCloseMobile,
  totalCount
}) => {
  const [openSections, setOpenSections] = useState({
    type: true,
    mode: true,
    category: true,
    audience: true,
    cost: true,
    prize: true
  });

  const toggleSection = (section: keyof typeof openSections) => {
    setOpenSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const handleCheckboxToggle = (
    key: 'types' | 'modes' | 'categories' | 'audience' | 'costs',
    val: string
  ) => {
    const list = filters[key] || [];
    const exists = list.includes(val);
    const updated = exists ? list.filter(item => item !== val) : [...list, val];
    onChange({ ...filters, [key]: updated });
  };

  const handlePrizeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const minVal = parseInt(e.target.value, 10);
    onChange({ ...filters, minPrize: minVal });
  };

  const hasActiveFilters = Boolean(
    (filters.types && filters.types.length > 0) ||
    (filters.modes && filters.modes.length > 0) ||
    (filters.categories && filters.categories.length > 0) ||
    (filters.audience && filters.audience.length > 0) ||
    (filters.costs && filters.costs.length > 0) ||
    (filters.minPrize && filters.minPrize > 0)
  );

  const content = (
    <div className="space-y-6">
      {/* Header with Clear Button */}
      <div className="flex items-center justify-between pb-3 border-b border-[#334155]">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-cyan-400" />
          <h3 className="text-sm font-bold text-[#f8fafc] uppercase tracking-wider">Filters</h3>
          {totalCount !== undefined && (
            <span className="text-xs px-2 py-0.5 rounded-full bg-[#1e293b] text-slate-300 font-semibold border border-[#334155]">
              {totalCount}
            </span>
          )}
        </div>
        {hasActiveFilters && (
          <button
            onClick={onClear}
            className="flex items-center gap-1 text-xs text-[#a78bfa] hover:text-purple-300 font-medium transition-colors"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Clear Filters</span>
          </button>
        )}
      </div>

      {/* Section: Event Type */}
      <div className="space-y-2 border-b border-[#334155]/60 pb-5">
        <button
          onClick={() => toggleSection('type')}
          className="flex items-center justify-between w-full text-left text-xs font-semibold text-[#cbd5e1] uppercase tracking-wider"
        >
          <span>Event Type</span>
          {openSections.type ? <ChevronUp className="w-3.5 h-3.5 text-slate-400" /> : <ChevronDown className="w-3.5 h-3.5 text-slate-400" />}
        </button>
        {openSections.type && (
          <div className="grid grid-cols-1 gap-2 pt-2">
            {EVENT_TYPES.map((t) => {
              const checked = (filters.types || []).includes(t.id);
              return (
                <label key={t.id} className="flex items-center gap-2.5 text-xs text-slate-300 hover:text-white cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={() => handleCheckboxToggle('types', t.id)}
                    className="w-4 h-4 rounded bg-[#0f172a] border-[#334155] text-[#7c3aed] focus:ring-0 focus:ring-offset-0 cursor-pointer accent-[#7c3aed]"
                  />
                  <span>{t.label}</span>
                </label>
              );
            })}
          </div>
        )}
      </div>

      {/* Section: Mode */}
      <div className="space-y-2 border-b border-[#334155]/60 pb-5">
        <button
          onClick={() => toggleSection('mode')}
          className="flex items-center justify-between w-full text-left text-xs font-semibold text-[#cbd5e1] uppercase tracking-wider"
        >
          <span>Mode</span>
          {openSections.mode ? <ChevronUp className="w-3.5 h-3.5 text-slate-400" /> : <ChevronDown className="w-3.5 h-3.5 text-slate-400" />}
        </button>
        {openSections.mode && (
          <div className="grid grid-cols-1 gap-2 pt-2">
            {MODES.map((m) => {
              const checked = (filters.modes || []).includes(m.id);
              return (
                <label key={m.id} className="flex items-center gap-2.5 text-xs text-slate-300 hover:text-white cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={() => handleCheckboxToggle('modes', m.id)}
                    className="w-4 h-4 rounded bg-[#0f172a] border-[#334155] text-[#7c3aed] focus:ring-0 focus:ring-offset-0 cursor-pointer accent-[#7c3aed]"
                  />
                  <span>{m.label}</span>
                </label>
              );
            })}
          </div>
        )}
      </div>

      {/* Section: Category */}
      <div className="space-y-2 border-b border-[#334155]/60 pb-5">
        <button
          onClick={() => toggleSection('category')}
          className="flex items-center justify-between w-full text-left text-xs font-semibold text-[#cbd5e1] uppercase tracking-wider"
        >
          <span>Category</span>
          {openSections.category ? <ChevronUp className="w-3.5 h-3.5 text-slate-400" /> : <ChevronDown className="w-3.5 h-3.5 text-slate-400" />}
        </button>
        {openSections.category && (
          <div className="grid grid-cols-1 gap-2 pt-2 max-h-48 overflow-y-auto pr-1">
            {EVENT_CATEGORIES.filter(c => c.id !== 'all').map((cat) => {
              const checked = (filters.categories || []).includes(cat.name);
              return (
                <label key={cat.id} className="flex items-center gap-2.5 text-xs text-slate-300 hover:text-white cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={() => handleCheckboxToggle('categories', cat.name)}
                    className="w-4 h-4 rounded bg-[#0f172a] border-[#334155] text-[#7c3aed] focus:ring-0 focus:ring-offset-0 cursor-pointer accent-[#7c3aed]"
                  />
                  <span className="truncate">{cat.emoji} {cat.name}</span>
                </label>
              );
            })}
          </div>
        )}
      </div>

      {/* Section: Audience */}
      <div className="space-y-2 border-b border-[#334155]/60 pb-5">
        <button
          onClick={() => toggleSection('audience')}
          className="flex items-center justify-between w-full text-left text-xs font-semibold text-[#cbd5e1] uppercase tracking-wider"
        >
          <span>Audience</span>
          {openSections.audience ? <ChevronUp className="w-3.5 h-3.5 text-slate-400" /> : <ChevronDown className="w-3.5 h-3.5 text-slate-400" />}
        </button>
        {openSections.audience && (
          <div className="grid grid-cols-1 gap-2 pt-2">
            {AUDIENCES.map((a) => {
              const checked = (filters.audience || []).includes(a.id);
              return (
                <label key={a.id} className="flex items-center gap-2.5 text-xs text-slate-300 hover:text-white cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={() => handleCheckboxToggle('audience', a.id)}
                    className="w-4 h-4 rounded bg-[#0f172a] border-[#334155] text-[#7c3aed] focus:ring-0 focus:ring-offset-0 cursor-pointer accent-[#7c3aed]"
                  />
                  <span>{a.label}</span>
                </label>
              );
            })}
          </div>
        )}
      </div>

      {/* Section: Cost */}
      <div className="space-y-2 border-b border-[#334155]/60 pb-5">
        <button
          onClick={() => toggleSection('cost')}
          className="flex items-center justify-between w-full text-left text-xs font-semibold text-[#cbd5e1] uppercase tracking-wider"
        >
          <span>Cost</span>
          {openSections.cost ? <ChevronUp className="w-3.5 h-3.5 text-slate-400" /> : <ChevronDown className="w-3.5 h-3.5 text-slate-400" />}
        </button>
        {openSections.cost && (
          <div className="grid grid-cols-1 gap-2 pt-2">
            {COSTS.map((c) => {
              const checked = (filters.costs || []).includes(c.id);
              return (
                <label key={c.id} className="flex items-center gap-2.5 text-xs text-slate-300 hover:text-white cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={() => handleCheckboxToggle('costs', c.id)}
                    className="w-4 h-4 rounded bg-[#0f172a] border-[#334155] text-[#7c3aed] focus:ring-0 focus:ring-offset-0 cursor-pointer accent-[#7c3aed]"
                  />
                  <span>{c.label}</span>
                </label>
              );
            })}
          </div>
        )}
      </div>

      {/* Section: Prize Range Slider */}
      <div className="space-y-2 pb-2">
        <button
          onClick={() => toggleSection('prize')}
          className="flex items-center justify-between w-full text-left text-xs font-semibold text-[#cbd5e1] uppercase tracking-wider"
        >
          <span>Min Prize Pool</span>
          {openSections.prize ? <ChevronUp className="w-3.5 h-3.5 text-slate-400" /> : <ChevronDown className="w-3.5 h-3.5 text-slate-400" />}
        </button>
        {openSections.prize && (
          <div className="pt-2 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
              <span>₹0</span>
              <span className="text-[#a78bfa] font-bold">
                {filters.minPrize && filters.minPrize > 0
                  ? `₹${filters.minPrize.toLocaleString('en-IN')}+`
                  : 'Any'}
              </span>
              <span>₹5,00,000</span>
            </div>
            <input
              type="range"
              min="0"
              max="500000"
              step="25000"
              value={filters.minPrize || 0}
              onChange={handlePrizeChange}
              className="w-full h-1.5 bg-[#1e293b] rounded-lg appearance-none cursor-pointer accent-[#7c3aed]"
            />
          </div>
        )}
      </div>

    </div>
  );

  // If used in mobile drawer/modal mode
  if (isMobileDrawer) {
    if (!isOpenMobile) return null;
    return (
      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
        <div className="fixed inset-0" onClick={onCloseMobile} />
        <div className="relative w-full max-w-lg rounded-t-3xl sm:rounded-2xl bg-[#172033] border border-[#334155] p-6 max-h-[85vh] overflow-y-auto z-10">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-[#334155]">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Filter className="w-4 h-4 text-cyan-400" />
              Filter Opportunities
            </h3>
            <button
              onClick={onCloseMobile}
              className="p-1 rounded-lg text-[#94a3b8] hover:text-white bg-[#1e293b]"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          {content}
          <div className="mt-6 pt-4 border-t border-[#334155]">
            <button
              onClick={onCloseMobile}
              className="w-full py-2.5 rounded-xl bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-sm font-semibold shadow-md"
            >
              Show Results
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Desktop inline sidebar
  return (
    <aside className="w-full p-5 rounded-2xl bg-[#172033]/70 border border-[#334155] sticky top-20">
      {content}
    </aside>
  );
};
