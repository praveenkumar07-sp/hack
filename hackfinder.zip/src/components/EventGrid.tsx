import React from 'react';
import { EventItem } from '../types';
import { EventCard } from './EventCard';
import { EmptyState } from './EmptyState';
import { Sparkles } from 'lucide-react';

interface EventGridProps {
  events: EventItem[];
  emptyTitle?: string;
  emptyDescription?: string;
  emptyActionText?: string;
  emptyActionHref?: string;
  onSaveToggle?: (eventId: string, isSaved: boolean) => void;
}

export const EventGrid: React.FC<EventGridProps> = ({
  events,
  emptyTitle = 'No opportunities found',
  emptyDescription = 'Try adjusting your filters or search keywords to discover more tech events.',
  emptyActionText = 'Clear Filters',
  emptyActionHref,
  onSaveToggle
}) => {
  if (events.length === 0) {
    return (
      <EmptyState
        icon={<Sparkles className="w-8 h-8 text-[#a78bfa]" />}
        title={emptyTitle}
        description={emptyDescription}
        actionText={emptyActionText}
        actionHref={emptyActionHref}
      />
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {events.map((event) => (
        <EventCard key={event.id} event={event} onSaveToggle={onSaveToggle} />
      ))}
    </div>
  );
};
