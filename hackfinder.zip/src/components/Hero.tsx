import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Search, Sparkles, Trophy, Flame, Bot, Globe, ArrowRight } from 'lucide-react';

export const Hero: React.FC = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/events?search=${encodeURIComponent(searchTerm.trim())}`);
    } else {
      navigate('/events');
    }
  };

  return (
    <section className="relative overflow-hidden pt-12 pb-20 md:py-24 border-b border-[#334155]/40">
      
      {/* Background Glows & Gradients */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-r from-purple-600/20 via-cyan-500/15 to-purple-800/10 blur-[100px] pointer-events-none rounded-full" />
      <div className="absolute top-0 right-1/4 w-72 h-72 bg-cyan-500/10 blur-[90px] pointer-events-none rounded-full" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Floating Mini Cards (Desktop / Tablet view) */}
        <div className="hidden lg:block">
          {/* Card 1: Top Left */}
          <div className="absolute -top-4 left-4 xl:left-8 px-3.5 py-2 rounded-xl glass-card text-xs font-semibold text-amber-300 flex items-center gap-2 animate-bounce duration-1000 shadow-lg shadow-black/40">
            <span className="p-1 rounded-md bg-amber-500/20 text-amber-400">
              <Trophy className="w-3.5 h-3.5" />
            </span>
            <span>🏆 ₹1,00,000 Prize</span>
          </div>

          {/* Card 2: Top Right */}
          <div className="absolute top-2 right-4 xl:right-12 px-3.5 py-2 rounded-xl glass-card text-xs font-semibold text-rose-300 flex items-center gap-2 shadow-lg shadow-black/40">
            <span className="p-1 rounded-md bg-rose-500/20 text-rose-400">
              <Flame className="w-3.5 h-3.5" />
            </span>
            <span>🔥 Trending</span>
          </div>

          {/* Card 3: Bottom Left */}
          <div className="absolute bottom-6 left-6 xl:left-14 px-3.5 py-2 rounded-xl glass-card text-xs font-semibold text-purple-300 flex items-center gap-2 shadow-lg shadow-black/40">
            <span className="p-1 rounded-md bg-purple-500/20 text-purple-400">
              <Bot className="w-3.5 h-3.5" />
            </span>
            <span>🤖 AI Hackathon</span>
          </div>

          {/* Card 4: Bottom Right */}
          <div className="absolute bottom-4 right-8 xl:right-16 px-3.5 py-2 rounded-xl glass-card text-xs font-semibold text-cyan-300 flex items-center gap-2 shadow-lg shadow-black/40">
            <span className="p-1 rounded-md bg-cyan-500/20 text-cyan-400">
              <Globe className="w-3.5 h-3.5" />
            </span>
            <span>🌎 Global Event</span>
          </div>
        </div>

        {/* Central Content */}
        <div className="max-w-3xl mx-auto text-center space-y-6">
          
          {/* Brand Tag Pill */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#1e293b]/90 border border-[#334155] text-xs font-medium text-slate-300 shadow-inner">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>Discover Verified Tech & Career Opportunities</span>
          </div>

          {/* Hero Headline */}
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-white leading-[1.12]">
            Find Your Next <br />
            <span className="text-gradient">Breakthrough.</span>
          </h1>

          {/* Supporting Text */}
          <p className="text-base sm:text-lg text-[#94a3b8] max-w-2xl mx-auto leading-relaxed">
            Discover hackathons, conferences, certifications, workshops, and opportunities that move your career forward.
          </p>

          {/* Search Box */}
          <form
            onSubmit={handleSearch}
            className="relative max-w-2xl mx-auto flex items-center rounded-2xl bg-[#172033]/90 border border-[#334155] p-2 shadow-2xl shadow-purple-950/30 focus-within:border-[#7c3aed] transition-all"
          >
            <div className="flex items-center pl-3 text-[#94a3b8]">
              <Search className="w-5 h-5 text-slate-400" />
            </div>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search events, skills, organizations, domains..."
              className="w-full bg-transparent px-3 py-2 text-sm sm:text-base text-white placeholder-slate-400 focus:outline-none"
            />
            <button
              type="submit"
              className="shrink-0 px-5 py-2.5 rounded-xl bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-sm font-semibold transition-all shadow-md shadow-purple-600/30 active:scale-95 flex items-center gap-1.5"
            >
              <span>Search</span>
              <ArrowRight className="w-4 h-4 hidden sm:inline" />
            </button>
          </form>

          {/* Quick CTA Buttons */}
          <div className="flex items-center justify-center gap-3 pt-2">
            <Link
              to="/events"
              className="px-5 py-2.5 rounded-xl bg-[#1e293b] hover:bg-[#334155] text-white text-sm font-semibold border border-[#334155] transition-colors shadow-sm"
            >
              Explore Events
            </Link>
            <Link
              to="/ai-recommend"
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#7c3aed]/20 to-[#06b6d4]/20 hover:from-[#7c3aed]/30 hover:to-[#06b6d4]/30 text-cyan-300 text-sm font-semibold border border-cyan-500/40 transition-all flex items-center gap-2 shadow-sm"
            >
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>✨ Ask AI</span>
            </Link>
          </div>

          {/* Mobile floating tags row */}
          <div className="flex lg:hidden items-center justify-center gap-2 flex-wrap pt-4 text-xs font-semibold">
            <span className="px-2.5 py-1 rounded-lg bg-[#1e293b] text-amber-300 border border-[#334155]">
              🏆 ₹1,00,000 Prize
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-[#1e293b] text-rose-300 border border-[#334155]">
              🔥 Trending
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-[#1e293b] text-purple-300 border border-[#334155]">
              🤖 AI Hackathon
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-[#1e293b] text-cyan-300 border border-[#334155]">
              🌎 Global Event
            </span>
          </div>

        </div>

      </div>
    </section>
  );
};
