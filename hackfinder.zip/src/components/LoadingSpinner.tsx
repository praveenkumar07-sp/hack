import React from 'react';

interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  label?: string;
}

export const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ size = 'md', label }) => {
  const sizeClasses = {
    sm: 'w-4 h-4 border-2',
    md: 'w-8 h-8 border-3',
    lg: 'w-12 h-12 border-4'
  };

  return (
    <div className="flex flex-col items-center justify-center py-10 gap-3">
      <div
        className={`${sizeClasses[size]} rounded-full border-t-[#7c3aed] border-r-[#06b6d4] border-b-[#7c3aed] border-l-transparent animate-spin`}
      />
      {label && <p className="text-xs text-[#94a3b8] font-medium tracking-wide">{label}</p>}
    </div>
  );
};
