import React from 'react';
import { Link } from 'react-router-dom';
import { Sparkles, ArrowRight } from 'lucide-react';

interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description: string;
  actionText?: string;
  actionHref?: string;
  onActionClick?: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon,
  title,
  description,
  actionText,
  actionHref,
  onActionClick
}) => {
  return (
    <div className="flex flex-col items-center justify-center p-12 text-center rounded-2xl bg-[#172033]/60 border border-[#334155]/60 max-w-lg mx-auto my-8">
      <div className="w-16 h-16 rounded-2xl bg-[#1e293b] border border-[#334155] flex items-center justify-center text-[#c084fc] mb-5 shadow-inner">
        {icon || <Sparkles className="w-8 h-8 text-[#a78bfa]" />}
      </div>
      <h3 className="text-xl font-bold text-[#f8fafc] mb-2">{title}</h3>
      <p className="text-sm text-[#94a3b8] leading-relaxed mb-6 max-w-sm">{description}</p>
      {actionText && (
        actionHref ? (
          <Link
            to={actionHref}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-sm font-semibold transition-all duration-200 shadow-lg shadow-purple-600/25 active:scale-95"
          >
            {actionText}
            <ArrowRight className="w-4 h-4" />
          </Link>
        ) : (
          <button
            onClick={onActionClick}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-sm font-semibold transition-all duration-200 shadow-lg shadow-purple-600/25 active:scale-95"
          >
            {actionText}
            <ArrowRight className="w-4 h-4" />
          </button>
        )
      )}
    </div>
  );
};
