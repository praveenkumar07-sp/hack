import React from 'react';
import { Link } from 'react-router-dom';
import { Sparkles, Github, Twitter, Linkedin, Mail, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full bg-[#0b1120] border-t border-[#334155]/60 mt-20 text-[#94a3b8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          
          {/* Col 1: Brand & Tagline */}
          <div className="lg:col-span-2 space-y-4">
            <Link to="/" className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#7c3aed] to-[#06b6d4] flex items-center justify-center shadow-md">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <span className="text-xl font-extrabold tracking-tight text-white">
                Hack<span className="text-gradient">Finder</span>
              </span>
            </Link>
            <p className="text-sm text-[#cbd5e1] font-medium">
              Find Your Next Breakthrough
            </p>
            <p className="text-xs text-[#94a3b8] leading-relaxed max-w-sm">
              Discover hackathons, conferences, certifications, workshops, and opportunities that move your career forward. Built for curious builders and ambitious teams.
            </p>
            <div className="flex items-center gap-3 pt-2">
              <a
                href="https://github.com"
                target="_blank"
                rel="noreferrer"
                className="w-8 h-8 rounded-lg bg-[#172033] border border-[#334155] flex items-center justify-center text-[#94a3b8] hover:text-[#f8fafc] hover:border-[#7c3aed] transition-colors"
                aria-label="GitHub"
              >
                <Github className="w-4 h-4" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noreferrer"
                className="w-8 h-8 rounded-lg bg-[#172033] border border-[#334155] flex items-center justify-center text-[#94a3b8] hover:text-[#f8fafc] hover:border-[#06b6d4] transition-colors"
                aria-label="Twitter"
              >
                <Twitter className="w-4 h-4" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noreferrer"
                className="w-8 h-8 rounded-lg bg-[#172033] border border-[#334155] flex items-center justify-center text-[#94a3b8] hover:text-[#f8fafc] hover:border-[#7c3aed] transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-4 h-4" />
              </a>
              <a
                href="mailto:contact@hackfinder.dev"
                className="w-8 h-8 rounded-lg bg-[#172033] border border-[#334155] flex items-center justify-center text-[#94a3b8] hover:text-[#f8fafc] hover:border-emerald-500 transition-colors"
                aria-label="Email"
              >
                <Mail className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Col 2: Explore */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#f8fafc]">Explore</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <Link to="/events" className="hover:text-[#c084fc] transition-colors">
                  All Events
                </Link>
              </li>
              <li>
                <Link to="/trending" className="hover:text-[#c084fc] transition-colors">
                  Trending Opportunities
                </Link>
              </li>
              <li>
                <Link to="/organizations" className="hover:text-[#c084fc] transition-colors">
                  Top Organizations
                </Link>
              </li>
              <li>
                <Link to="/ai-recommend" className="hover:text-cyan-400 transition-colors flex items-center gap-1">
                  <span>AI Recommendations</span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 font-semibold">NEW</span>
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 3: Community */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#f8fafc]">Community</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <Link to="/teammates" className="hover:text-[#c084fc] transition-colors">
                  Find Teammates
                </Link>
              </li>
              <li>
                <Link to="/post-event" className="hover:text-[#c084fc] transition-colors">
                  Post an Event
                </Link>
              </li>
              <li>
                <Link to="/admin" className="hover:text-[#c084fc] transition-colors">
                  Admin Verification
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 4: Account */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#f8fafc]">Account</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <Link to="/saved" className="hover:text-[#c084fc] transition-colors">
                  Saved Events
                </Link>
              </li>
              <li>
                <Link to="/profile" className="hover:text-[#c084fc] transition-colors">
                  User Profile
                </Link>
              </li>
              <li>
                <Link to="/login" className="hover:text-[#c084fc] transition-colors">
                  Sign In
                </Link>
              </li>
              <li>
                <Link to="/register" className="hover:text-[#c084fc] transition-colors">
                  Create Account
                </Link>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-10 mt-10 border-t border-[#334155]/40 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <p>© 2026 HackFinder. All rights reserved.</p>
          <div className="flex items-center gap-1 text-[#64748b]">
            <span>Designed for ambitious builders worldwide</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
