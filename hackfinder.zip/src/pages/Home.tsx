import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ArrowRight,
  Sparkles,
  Flame,
  Clock,
  Search,
  Users,
  Compass,
  Rocket,
  ShieldCheck,
  Award
} from 'lucide-react';
import { Hero } from '../components/Hero';
import { EventCard } from '../components/EventCard';
import { EVENT_CATEGORIES } from '../data/events';
import { getAllEvents } from '../utils/storage';
import { getEventStatus } from '../utils/filters';

export const Home: React.FC = () => {
  const navigate = useNavigate();
  const allEvents = getAllEvents();

  // Featured Opportunities (4 events)
  const featuredEvents = allEvents.filter(e => e.featured).slice(0, 4);

  // Trending Section (4-6 events)
  const trendingEvents = allEvents.filter(e => e.trending).slice(0, 6);

  // Closing Soon (events with deadline <= 7 days)
  const closingSoonEvents = allEvents
    .filter(e => {
      const { isClosingSoon } = getEventStatus(e);
      return isClosingSoon;
    })
    .slice(0, 3);

  const whyCards = [
    {
      icon: Search,
      title: '🔎 Discover',
      desc: 'Find opportunities from multiple domains including hackathons, conferences, and fellowships.',
      color: 'text-purple-400',
      border: 'hover:border-purple-500/50'
    },
    {
      icon: Sparkles,
      title: '✨ Personalize',
      desc: 'Discover curated events tailored to your technical skills, interests, and academic level.',
      color: 'text-cyan-400',
      border: 'hover:border-cyan-500/50'
    },
    {
      icon: Users,
      title: '👥 Collaborate',
      desc: 'Find compatible teammates with complementary skills to build hackathon-winning prototypes.',
      color: 'text-amber-400',
      border: 'hover:border-amber-500/50'
    },
    {
      icon: Rocket,
      title: '🚀 Grow',
      desc: 'Build verifiable credentials, win cash grants, and unlock career-defining internships.',
      color: 'text-emerald-400',
      border: 'hover:border-emerald-500/50'
    }
  ];

  return (
    <div className="space-y-16 sm:space-y-24">
      {/* 6. Hero Section */}
      <Hero />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-20 sm:space-y-28">

        {/* 7. Quick Categories */}
        <section className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                Explore by Category
              </h2>
              <p className="text-xs sm:text-sm text-[#94a3b8] mt-1">
                Browse curated tech opportunities organized by specialization.
              </p>
            </div>
            <Link
              to="/events"
              className="text-xs sm:text-sm font-semibold text-[#a78bfa] hover:text-white flex items-center gap-1 transition-colors"
            >
              <span>View All</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
            {EVENT_CATEGORIES.filter(c => c.id !== 'all').map((cat) => {
              const count = allEvents.filter(e => e.category === cat.name).length;
              return (
                <button
                  key={cat.id}
                  onClick={() => navigate(`/events?category=${encodeURIComponent(cat.name)}`)}
                  className="flex items-center gap-3.5 p-4 rounded-xl bg-[#172033]/80 hover:bg-[#1e293b] border border-[#334155] hover:border-[#7c3aed]/50 transition-all text-left group shadow-sm hover:-translate-y-0.5"
                >
                  <span className="text-2xl shrink-0 group-hover:scale-110 transition-transform">
                    {cat.emoji}
                  </span>
                  <div className="overflow-hidden">
                    <h3 className="text-xs sm:text-sm font-bold text-slate-100 group-hover:text-cyan-300 transition-colors truncate">
                      {cat.name}
                    </h3>
                    <p className="text-[11px] text-[#94a3b8]">
                      {count} opportunities
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {/* 8. Featured Events */}
        <section className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-purple-500/10 border border-purple-500/30 text-[#a78bfa]">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  Featured Opportunities
                </h2>
                <p className="text-xs sm:text-sm text-[#94a3b8] mt-1">
                  Hand-picked flagship events with substantial prizes and global recognition.
                </p>
              </div>
            </div>
            <Link
              to="/events?filter=featured"
              className="text-xs sm:text-sm font-semibold text-[#a78bfa] hover:text-white flex items-center gap-1 transition-colors"
            >
              <span>View All</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredEvents.map((event) => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        </section>

        {/* 9. Trending Section */}
        <section className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400">
                <Flame className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2">
                  <span>Trending Now</span>
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40">
                    High Demand
                  </span>
                </h2>
                <p className="text-xs sm:text-sm text-[#94a3b8] mt-1">
                  The most actively viewed and saved events across the community this week.
                </p>
              </div>
            </div>
            <Link
              to="/trending"
              className="text-xs sm:text-sm font-semibold text-[#a78bfa] hover:text-white flex items-center gap-1 transition-colors"
            >
              <span>Explore Trending</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {trendingEvents.map((event) => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        </section>

        {/* 10. Closing Soon */}
        {closingSoonEvents.length > 0 && (
          <section className="p-6 sm:p-8 rounded-3xl bg-gradient-to-b from-amber-500/10 via-[#172033] to-[#172033] border border-amber-500/30 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400">
                  <Clock className="w-6 h-6 animate-spin" style={{ animationDuration: '8s' }} />
                </div>
                <div>
                  <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
                    <span>⏳ Closing Soon</span>
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/30 text-amber-300 font-bold">
                      URGENT
                    </span>
                  </h2>
                  <p className="text-xs sm:text-sm text-amber-200/80 mt-0.5">
                    Don't miss these opportunities. Registration deadlines expire within a few days!
                  </p>
                </div>
              </div>

              <Link
                to="/events?filter=closingSoon"
                className="self-start sm:self-auto px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-all shadow-md shadow-amber-500/20 flex items-center gap-1.5"
              >
                <span>View All Closing Events</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {closingSoonEvents.map((event) => (
                <EventCard key={event.id} event={event} />
              ))}
            </div>
          </section>
        )}

        {/* 11. Why HackFinder */}
        <section className="space-y-10 pt-4">
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">
              Platform Features
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              Why HackFinder?
            </h2>
            <p className="text-sm text-[#94a3b8]">
              Built to bridge the gap between ambitious builders and global innovation opportunities.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {whyCards.map((card) => {
              const Icon = card.icon;
              return (
                <div
                  key={card.title}
                  className={`p-6 rounded-2xl bg-[#172033]/70 border border-[#334155] transition-all duration-300 ${card.border} hover:-translate-y-1 hover:shadow-xl hover:shadow-black/30 space-y-4`}
                >
                  <div className={`w-12 h-12 rounded-xl bg-[#1e293b] border border-[#334155] flex items-center justify-center ${card.color}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-white">{card.title}</h3>
                  <p className="text-xs text-[#94a3b8] leading-relaxed">
                    {card.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </section>

        {/* 12. Large CTA */}
        <section className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#7c3aed] via-[#5b21b6] to-[#06b6d4] p-8 sm:p-12 md:p-16 text-center text-white shadow-2xl shadow-purple-950/50">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-white/10 via-transparent to-black/20 pointer-events-none" />
          
          <div className="relative max-w-2xl mx-auto space-y-6">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight leading-tight">
              Ready to find your next opportunity?
            </h2>
            <p className="text-base sm:text-lg text-purple-100/90 leading-relaxed max-w-xl mx-auto">
              Explore thousands of possibilities, form winning teams, and start building your future today.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <Link
                to="/events"
                className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-white text-purple-900 hover:bg-slate-100 text-sm font-bold transition-all shadow-xl shadow-black/20 active:scale-95"
              >
                Explore Events
              </Link>
              <Link
                to="/ai-recommend"
                className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-purple-950/40 hover:bg-purple-950/60 text-white text-sm font-semibold border border-white/20 transition-all flex items-center justify-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-cyan-300" />
                <span>Try AI Match</span>
              </Link>
            </div>
          </div>
        </section>

      </div>
    </div>
  );
};
