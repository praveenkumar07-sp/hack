import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Sparkles, Mail, Lock, ArrowRight, CheckCircle2 } from 'lucide-react';

export const Login: React.FC = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('arjun.patel@dev.edu');
  const [password, setPassword] = useState('••••••••••••');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      navigate('/profile');
    }, 400);
  };

  return (
    <div className="min-h-[75vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md rounded-3xl bg-[#172033]/90 border border-[#334155] p-8 sm:p-10 shadow-2xl shadow-purple-950/40 space-y-6">
        
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#7c3aed] to-[#06b6d4] flex items-center justify-center mx-auto shadow-md">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight">
            Welcome Back to HackFinder
          </h2>
          <p className="text-xs text-[#94a3b8]">
            Sign in to access your saved opportunities, hackathon teams, and notifications.
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 absolute left-3.5 top-3 text-[#94a3b8]" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-3 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-xs sm:text-sm focus:outline-none focus:border-[#7c3aed]"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-300">Password</label>
              <a href="#forgot" onClick={(e) => { e.preventDefault(); alert('Password reset simulation sent to email.'); }} className="text-xs text-[#c084fc] hover:underline">
                Forgot?
              </a>
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 absolute left-3.5 top-3 text-[#94a3b8]" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-3 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-xs sm:text-sm focus:outline-none focus:border-[#7c3aed]"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-sm font-bold transition-all shadow-lg shadow-purple-600/30 active:scale-95 flex items-center justify-center gap-2"
          >
            <span>{loading ? 'Authenticating...' : 'Sign In'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Demo Credentials note */}
        <div className="p-3 rounded-xl bg-[#1e293b] border border-[#334155] text-xs text-slate-400 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>Demo prototype credentials pre-populated. Click <strong>Sign In</strong> to proceed.</span>
        </div>

        {/* Footer link */}
        <div className="text-center text-xs text-[#94a3b8] pt-2 border-t border-[#334155]/60">
          Don't have an account?{' '}
          <Link to="/register" className="text-[#c084fc] font-bold hover:underline">
            Create an Account
          </Link>
        </div>

      </div>
    </div>
  );
};
