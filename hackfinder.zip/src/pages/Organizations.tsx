import React, { useState, useMemo } from 'react';
import { Building2, Search, CheckCircle, Sparkles } from 'lucide-react';
import { INITIAL_ORGANIZATIONS } from '../data/events';
import { OrganizationCard } from '../components/OrganizationCard';
import { SearchBar } from '../components/SearchBar';

export const Organizations: React.FC = () => {
  const [search, setSearch] = useState('');

  const filteredOrgs = useMemo(() => {
    if (!search.trim()) return INITIAL_ORGANIZATIONS;
    const q = search.toLowerCase().trim();
    return INITIAL_ORGANIZATIONS.filter(
      (org) =>
        org.name.toLowerCase().includes(q) ||
        org.description.toLowerCase().includes(q) ||
        org.domains.some((d) => d.toLowerCase().includes(q)) ||
        org.location.toLowerCase().includes(q)
    );
  }, [search]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-[#334155]/60">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
            <Building2 className="w-3.5 h-3.5 text-cyan-400" />
            <span>Verified Organizers</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Explore Organizations
          </h1>
          <p className="text-sm text-[#94a3b8] leading-relaxed max-w-xl">
            Discover premier developer communities, top tech enterprises, and academic labs hosting official hackathons and conferences.
          </p>
        </div>

        <div className="text-sm font-semibold text-slate-300">
          <span className="text-cyan-400 font-bold">{filteredOrgs.length}</span> verified hosts
        </div>
      </div>

      {/* Search Input */}
      <div className="max-w-md">
        <SearchBar
          value={search}
          onChange={setSearch}
          placeholder="Search organizations, domains, locations..."
        />
      </div>

      {/* Organization Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredOrgs.map((org) => (
          <OrganizationCard key={org.slug} org={org} />
        ))}
      </div>

      {filteredOrgs.length === 0 && (
        <div className="p-12 text-center rounded-2xl bg-[#172033]/60 border border-[#334155] max-w-md mx-auto space-y-3">
          <Building2 className="w-8 h-8 text-[#94a3b8] mx-auto" />
          <h3 className="text-base font-bold text-white">No organizations match your query</h3>
          <p className="text-xs text-[#94a3b8]">Try searching by different tech domain or company name.</p>
          <button
            onClick={() => setSearch('')}
            className="px-4 py-2 rounded-xl bg-[#7c3aed] text-white text-xs font-semibold"
          >
            Clear Search
          </button>
        </div>
      )}

    </div>
  );
};
