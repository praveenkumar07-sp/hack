import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Calendar,
  MapPin,
  Trophy,
  CheckCircle,
  Flame,
  Star,
  Bookmark,
  ExternalLink,
  Share2,
  CalendarPlus,
  Check,
  Building2,
  Users,
  Shield,
  Layers,
  FileCheck
} from 'lucide-react';
import { getAllEvents, isEventSaved, toggleSaveEventId } from '../utils/storage';
import { EventItem } from '../types';
import { DeadlineBadge } from '../components/DeadlineBadge';
import { EventCard } from '../components/EventCard';
import { formatPrize } from '../utils/filters';
import { downloadEventICS } from '../utils/calendar';
import { Modal } from '../components/Modal';

export const EventDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const allEvents = getAllEvents();

  const event = allEvents.find((e) => e.id === id);

  const [saved, setSaved] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [mapModalOpen, setMapModalOpen] = useState(false);
  const [registeredSuccess, setRegisteredSuccess] = useState(false);

  useEffect(() => {
    if (event) {
      setSaved(isEventSaved(event.id));
      window.scrollTo(0, 0);
    }
  }, [id, event]);

  if (!event) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-2xl font-bold text-white">Event Not Found</h2>
        <p className="text-sm text-[#94a3b8]">
          The opportunity you are searching for does not exist or has been removed.
        </p>
        <Link
          to="/events"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#7c3aed] text-white text-sm font-semibold"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to All Events</span>
        </Link>
      </div>
    );
  }

  const handleSaveToggle = () => {
    const { isSaved } = toggleSaveEventId(event.id);
    setSaved(isSaved);
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleCalendarDownload = () => {
    downloadEventICS(event);
  };

  // Related events matching same category or type (excluding current)
  const relatedEvents = allEvents
    .filter((e) => e.id !== event.id && (e.category === event.category || e.type === event.type))
    .slice(0, 4);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-12">
      
      {/* Back link */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => navigate(-1)}
          className="inline-flex items-center gap-2 text-xs sm:text-sm font-medium text-[#94a3b8] hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Events</span>
        </button>

        <button
          onClick={handleShare}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#172033] hover:bg-[#1e293b] border border-[#334155] text-xs font-medium text-slate-300 transition-colors"
        >
          {copiedLink ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-300">Link Copied!</span>
            </>
          ) : (
            <>
              <Share2 className="w-3.5 h-3.5" />
              <span>Share Event</span>
            </>
          )}
        </button>
      </div>

      {/* Main Header Card / Hero Banner */}
      <div className="relative rounded-3xl bg-[#172033]/90 border border-[#334155] overflow-hidden shadow-2xl">
        {/* Banner image with overlay */}
        <div className="relative h-64 sm:h-80 w-full overflow-hidden bg-slate-900">
          <img
            src={event.image}
            alt={event.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#172033] via-[#172033]/70 to-black/30" />
        </div>

        {/* Content overlaid on bottom of banner */}
        <div className="relative p-6 sm:p-8 -mt-24 space-y-6">
          
          {/* Badges Row */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-3 py-1 rounded-md text-xs font-extrabold uppercase tracking-wider bg-[#7c3aed] text-white shadow-md">
              {event.type}
            </span>
            {event.trending && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-bold bg-rose-500 text-white shadow-md">
                <Flame className="w-3.5 h-3.5 fill-current" />
                TRENDING
              </span>
            )}
            {event.featured && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-bold bg-amber-500 text-slate-950 shadow-md">
                <Star className="w-3.5 h-3.5 fill-current" />
                FEATURED
              </span>
            )}
            {event.verified && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                <CheckCircle className="w-3.5 h-3.5" />
                VERIFIED
              </span>
            )}
            <DeadlineBadge event={event} />
          </div>

          {/* Title & Organization */}
          <div className="space-y-2">
            <h1 className="text-2xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight leading-tight">
              {event.title}
            </h1>
            <div className="flex items-center gap-2 text-sm text-[#cbd5e1]">
              <span className="text-[#94a3b8]">Organized by</span>
              <Link
                to={`/organizations/${encodeURIComponent(event.organization.toLowerCase().replace(/\s+/g, '-'))}`}
                className="font-bold text-white hover:text-cyan-400 transition-colors flex items-center gap-1"
              >
                <Building2 className="w-4 h-4 text-cyan-400" />
                <span>{event.organization}</span>
              </Link>
            </div>
          </div>

          {/* Key metadata chips */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
            <div className="p-3.5 rounded-2xl bg-[#1e293b]/80 border border-[#334155]">
              <span className="text-[11px] font-medium text-[#94a3b8] block">Specialization</span>
              <span className="text-xs sm:text-sm font-bold text-white">{event.category}</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-[#1e293b]/80 border border-[#334155]">
              <span className="text-[11px] font-medium text-[#94a3b8] block">Mode</span>
              <span className="text-xs sm:text-sm font-bold text-cyan-300">
                {event.mode} {event.city ? `(${event.city})` : ''}
              </span>
            </div>
            <div className="p-3.5 rounded-2xl bg-[#1e293b]/80 border border-[#334155]">
              <span className="text-[11px] font-medium text-[#94a3b8] block">Date</span>
              <span className="text-xs sm:text-sm font-bold text-white">
                {new Date(event.startDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} –{' '}
                {new Date(event.endDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
              </span>
            </div>
            <div className="p-3.5 rounded-2xl bg-[#1e293b]/80 border border-[#334155]">
              <span className="text-[11px] font-medium text-[#94a3b8] block">Prize Pool</span>
              <span className="text-xs sm:text-sm font-extrabold text-amber-300">
                {formatPrize(event.prizeAmount, event.currency)}
              </span>
            </div>
          </div>

          {/* Action Buttons Bar */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-3 border-t border-[#334155]">
            <a
              href={event.registrationUrl}
              target="_blank"
              rel="noreferrer"
              onClick={() => setRegisteredSuccess(true)}
              className="flex-1 py-3.5 px-6 rounded-xl bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-sm font-bold transition-all shadow-lg shadow-purple-600/30 flex items-center justify-center gap-2 active:scale-95"
            >
              <span>Register Now</span>
              <ExternalLink className="w-4 h-4" />
            </a>

            <button
              onClick={handleSaveToggle}
              className={`py-3.5 px-5 rounded-xl border text-sm font-semibold transition-all flex items-center justify-center gap-2 active:scale-95 ${
                saved
                  ? 'bg-[#7c3aed]/20 text-[#c084fc] border-[#7c3aed]'
                  : 'bg-[#1e293b] text-slate-200 border-[#334155] hover:border-slate-500'
              }`}
            >
              <Bookmark className={`w-4 h-4 ${saved ? 'fill-current text-[#c084fc]' : ''}`} />
              <span>{saved ? 'Saved in Account' : 'Save Opportunity'}</span>
            </button>

            <button
              onClick={handleCalendarDownload}
              className="py-3.5 px-5 rounded-xl bg-[#1e293b] hover:bg-[#334155] text-slate-200 border border-[#334155] text-sm font-semibold transition-colors flex items-center justify-center gap-2"
              title="Download .ics calendar event"
            >
              <CalendarPlus className="w-4 h-4 text-cyan-400" />
              <span>Add to Calendar</span>
            </button>
          </div>

          {registeredSuccess && (
            <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center gap-2">
              <CheckCircle className="w-4 h-4" />
              <span>Opening registration portal in new tab! You can also find teammates below.</span>
            </div>
          )}

        </div>
      </div>

      {/* Details Grid (Left 2 cols: Content, Right 1 col: Sidebar & Timeline) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        
        {/* Left 2 Cols */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* About Section */}
          <section className="p-6 sm:p-8 rounded-3xl bg-[#172033]/70 border border-[#334155] space-y-4">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <FileCheck className="w-5 h-5 text-cyan-400" />
              <span>About the Opportunity</span>
            </h2>
            <p className="text-sm text-[#cbd5e1] leading-relaxed">
              {event.about || event.description}
            </p>
            <p className="text-sm text-[#94a3b8] leading-relaxed">
              Whether you are an aspiring student builder or an experienced software engineer, this platform offers hands-on problem statements, mentorship sessions, and opportunities to connect with industry leaders.
            </p>
          </section>

          {/* Tracks Section */}
          {event.tracks && event.tracks.length > 0 && (
            <section className="p-6 sm:p-8 rounded-3xl bg-[#172033]/70 border border-[#334155] space-y-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Layers className="w-5 h-5 text-[#a78bfa]" />
                <span>Thematic Tracks & Problem Domains</span>
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {event.tracks.map((track, i) => (
                  <div
                    key={track}
                    className="p-3.5 rounded-xl bg-[#1e293b] border border-[#334155] flex items-center gap-3"
                  >
                    <span className="w-6 h-6 rounded-lg bg-[#7c3aed]/20 text-[#c084fc] text-xs font-bold flex items-center justify-center shrink-0">
                      {i + 1}
                    </span>
                    <span className="text-sm font-semibold text-slate-200">{track}</span>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Prize & Benefits */}
          <section className="p-6 sm:p-8 rounded-3xl bg-[#172033]/70 border border-[#334155] space-y-4">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Trophy className="w-5 h-5 text-amber-400" />
              <span>Prize & Key Benefits</span>
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {event.benefits && event.benefits.length > 0 ? (
                event.benefits.map((b) => (
                  <div
                    key={b}
                    className="p-3.5 rounded-xl bg-[#1e293b] border border-[#334155] flex items-start gap-2.5"
                  >
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span className="text-xs sm:text-sm text-slate-300 font-medium">{b}</span>
                  </div>
                ))
              ) : (
                <>
                  <div className="p-3.5 rounded-xl bg-[#1e293b] border border-[#334155] flex items-start gap-2.5">
                    <Trophy className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <span className="text-xs sm:text-sm text-slate-300 font-medium">
                      {formatPrize(event.prizeAmount, event.currency)} Cash Pool
                    </span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-[#1e293b] border border-[#334155] flex items-start gap-2.5">
                    <CheckCircle className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                    <span className="text-xs sm:text-sm text-slate-300 font-medium">
                      Digital Verified Certificate
                    </span>
                  </div>
                </>
              )}
            </div>
          </section>

          {/* Eligibility & Submission Type */}
          <section className="p-6 sm:p-8 rounded-3xl bg-[#172033]/70 border border-[#334155] space-y-4">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Shield className="w-5 h-5 text-cyan-400" />
              <span>Eligibility & Requirements</span>
            </h2>
            <div className="space-y-3 text-sm text-[#cbd5e1]">
              <p>
                <strong className="text-white">Audience: </strong>
                {event.eligibility || 'Open to students and software practitioners worldwide.'}
              </p>
              <p>
                <strong className="text-white">Submission Format: </strong>
                {event.submissionType || 'Working software prototype, GitHub repository, and live demo.'}
              </p>
              <p>
                <strong className="text-white">Registration Cost: </strong>
                {event.costType === 'free' ? (
                  <span className="text-emerald-400 font-bold">100% Free Entry</span>
                ) : event.costType === 'scholarship' ? (
                  <span className="text-cyan-400 font-bold">Scholarship Available</span>
                ) : (
                  <span className="text-amber-400 font-bold">Paid ({event.feeAmount ? `₹${event.feeAmount}` : 'Nominal Fee'})</span>
                )}
              </p>
            </div>
          </section>

          {/* Location & Map Section (If Offline or Hybrid) */}
          {event.mode !== 'Online' && (
            <section className="p-6 sm:p-8 rounded-3xl bg-[#172033]/70 border border-[#334155] space-y-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <MapPin className="w-5 h-5 text-rose-400" />
                <span>Venue Location</span>
              </h2>
              <div className="p-4 rounded-2xl bg-[#1e293b] border border-[#334155] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h4 className="text-sm font-bold text-white">
                    {event.city ? `${event.city}, ` : ''}{event.country}
                  </h4>
                  <p className="text-xs text-[#94a3b8] mt-0.5">
                    Physical venue coordination provided to confirmed participants.
                  </p>
                </div>
                <button
                  onClick={() => setMapModalOpen(true)}
                  className="px-4 py-2 rounded-xl bg-[#7c3aed]/20 hover:bg-[#7c3aed]/30 text-purple-300 text-xs font-bold border border-[#7c3aed]/40 transition-colors"
                >
                  View on Map
                </button>
              </div>
            </section>
          )}

        </div>

        {/* Right 1 Col: Timeline & Organization Summary */}
        <div className="space-y-6">
          
          {/* Important Dates Timeline */}
          <div className="p-6 rounded-3xl bg-[#172033]/80 border border-[#334155] space-y-5">
            <div className="flex items-center gap-2 pb-3 border-b border-[#334155]">
              <Calendar className="w-5 h-5 text-cyan-400" />
              <h3 className="text-base font-bold text-white">Important Dates</h3>
            </div>

            <div className="relative pl-6 space-y-6 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-[#334155]">
              {event.timeline && event.timeline.length > 0 ? (
                event.timeline.map((item, index) => {
                  const isDone = item.status === 'completed';
                  const isCurrent = item.status === 'current';
                  return (
                    <div key={item.stage} className="relative group">
                      <div
                        className={`absolute -left-[27px] top-1 w-3.5 h-3.5 rounded-full border-2 transition-all ${
                          isDone
                            ? 'bg-emerald-500 border-emerald-400'
                            : isCurrent
                            ? 'bg-[#7c3aed] border-[#c084fc] ring-4 ring-purple-500/20 animate-pulse'
                            : 'bg-slate-800 border-slate-600'
                        }`}
                      />
                      <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider block">
                        {item.date}
                      </span>
                      <h4 className="text-xs sm:text-sm font-semibold text-white mt-0.5">
                        {item.stage}
                      </h4>
                      {item.description && (
                        <p className="text-[11px] text-[#94a3b8] mt-1">{item.description}</p>
                      )}
                    </div>
                  );
                })
              ) : (
                <div className="relative">
                  <div className="absolute -left-[27px] top-1 w-3.5 h-3.5 rounded-full bg-[#7c3aed] border-2 border-[#c084fc]" />
                  <span className="text-[11px] font-bold text-cyan-400 uppercase">
                    Deadline
                  </span>
                  <h4 className="text-sm font-semibold text-white">
                    {event.registrationDeadline}
                  </h4>
                </div>
              )}
            </div>
          </div>

          {/* Need Teammates CTA */}
          <div className="p-6 rounded-3xl bg-gradient-to-br from-purple-900/30 to-[#172033] border border-purple-500/30 space-y-4 text-center">
            <div className="w-12 h-12 rounded-2xl bg-[#7c3aed]/20 text-[#a78bfa] flex items-center justify-center mx-auto">
              <Users className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">Need Teammates?</h3>
            <p className="text-xs text-[#94a3b8] leading-relaxed">
              Connect with fellow developers, designers, and domain specialists seeking squad members for this event.
            </p>
            <Link
              to="/teammates"
              className="block w-full py-2.5 px-4 rounded-xl bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-xs font-semibold shadow-md"
            >
              Find Teammates
            </Link>
          </div>

        </div>

      </div>

      {/* 19. Related Events */}
      {relatedEvents.length > 0 && (
        <div className="pt-12 border-t border-[#334155]/80 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-white tracking-tight">
                You May Also Like
              </h2>
              <p className="text-xs text-[#94a3b8] mt-1">
                More high-impact opportunities in {event.category} and related fields.
              </p>
            </div>
            <Link
              to={`/events?category=${encodeURIComponent(event.category)}`}
              className="text-xs font-semibold text-[#a78bfa] hover:text-white"
            >
              View More in {event.category} →
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedEvents.map((rel) => (
              <EventCard key={rel.id} event={rel} />
            ))}
          </div>
        </div>
      )}

      {/* Location Map Modal */}
      <Modal
        isOpen={mapModalOpen}
        onClose={() => setMapModalOpen(false)}
        title={`Venue Location: ${event.city ? `${event.city}, ` : ''}${event.country}`}
      >
        <div className="space-y-4">
          <div className="h-64 rounded-xl bg-slate-900 border border-[#334155] flex flex-col items-center justify-center text-center p-6 space-y-3">
            <MapPin className="w-10 h-10 text-rose-500 animate-bounce" />
            <h4 className="text-base font-bold text-white">
              {event.city ? `${event.city}, ` : ''}{event.country}
            </h4>
            <p className="text-xs text-[#94a3b8] max-w-sm">
              Official venue auditorium address and transit passes are provided in your confirmation email upon registration.
            </p>
          </div>
          <button
            onClick={() => setMapModalOpen(false)}
            className="w-full py-2.5 rounded-xl bg-[#1e293b] text-slate-200 text-xs font-semibold hover:bg-[#334155]"
          >
            Close Map
          </button>
        </div>
      </Modal>

    </div>
  );
};
