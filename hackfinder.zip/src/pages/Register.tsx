import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Sparkles, Mail, Lock, User, GraduationCap, ArrowRight } from 'lucide-react';
import { saveUserProfile, getUserProfile } from '../utils/storage';

export const Register: React.FC = () => {
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [university, setUniversity] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      const current = getUserProfile();
      saveUserProfile({
        ...current,
        name: name || current.name,
        email: email || current.email,
        university: university || current.university,
      });
      setLoading(false);
      navigate('/profile');
    }, 400);
  };

  return (
    <div className="min-h-[75vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md rounded-3xl bg-[#172033]/90 border border-[#334155] p-8 sm:p-10 shadow-2xl shadow-purple-950/40 space-y-6">
        
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#7c3aed] to-[#06b6d4] flex items-center justify-center mx-auto shadow-md">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight">
            Join HackFinder
          </h2>
          <p className="text-xs text-[#94a3b8]">
            Create a profile to discover events, save deadlines, and match with teammates worldwide.
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleRegister} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Full Name
            </label>
            <div className="relative">
              <User className="w-4 h-4 absolute left-3.5 top-3 text-[#94a3b8]" />
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Maya Chen"
                className="w-full pl-10 pr-3 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-xs sm:text-sm focus:outline-none focus:border-[#7c3aed]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 absolute left-3.5 top-3 text-[#94a3b8]" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="maya@university.edu"
                className="w-full pl-10 pr-3 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-xs sm:text-sm focus:outline-none focus:border-[#7c3aed]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              University / Organization
            </label>
            <div className="relative">
              <GraduationCap className="w-4 h-4 absolute left-3.5 top-3 text-[#94a3b8]" />
              <input
                type="text"
                required
                value={university}
                onChange={(e) => setUniversity(e.target.value)}
                placeholder="e.g. UC Berkeley"
                className="w-full pl-10 pr-3 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-xs sm:text-sm focus:outline-none focus:border-[#7c3aed]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 absolute left-3.5 top-3 text-[#94a3b8]" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Create a strong password"
                className="w-full pl-10 pr-3 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-xs sm:text-sm focus:outline-none focus:border-[#7c3aed]"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-sm font-bold transition-all shadow-lg shadow-purple-600/30 active:scale-95 flex items-center justify-center gap-2"
          >
            <span>{loading ? 'Creating Account...' : 'Create Account'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Footer link */}
        <div className="text-center text-xs text-[#94a3b8] pt-2 border-t border-[#334155]/60">
          Already have an account?{' '}
          <Link to="/login" className="text-[#c084fc] font-bold hover:underline">
            Sign In
          </Link>
        </div>

      </div>
    </div>
  );
};
