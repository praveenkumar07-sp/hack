import React, { useState } from 'react';
import {
  Sparkles,
  Bot,
  ArrowRight,
  Filter,
  CheckCircle2,
  HelpCircle,
  RotateCcw
} from 'lucide-react';
import { parseAiQuery, AiAnalysisResult } from '../utils/aiParser';
import { getAllEvents } from '../utils/storage';
import { EventCard } from '../components/EventCard';
import { LoadingSpinner } from '../components/LoadingSpinner';

export const AiRecommend: React.FC = () => {
  const [query, setQuery] = useState(
    'I am a 3rd year CS student looking for online AI hackathons with good prize pools'
  );
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<AiAnalysisResult | null>(() => {
    // Initial recommendation
    return parseAiQuery(
      'I am a 3rd year CS student looking for online AI hackathons with good prize pools',
      getAllEvents()
    );
  });

  const samplePrompts = [
    'Free AI hackathons for undergraduate students',
    'Offline conferences in India for cybersecurity',
    'Beginner-friendly web development workshops',
    'Global fellowship opportunities in data science',
  ];

  const handleMatch = (textToMatch: string) => {
    setLoading(true);
    setQuery(textToMatch);

    // Simulate snappy realistic AI inference latency
    setTimeout(() => {
      const result = parseAiQuery(textToMatch, getAllEvents());
      setAnalysis(result);
      setLoading(false);
    }, 450);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      handleMatch(query.trim());
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-10">
      
      {/* Header */}
      <div className="max-w-3xl mx-auto text-center space-y-4">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold bg-gradient-to-r from-[#7c3aed]/20 to-[#06b6d4]/20 text-cyan-300 border border-cyan-500/30">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          <span>Semantic Natural Language Matcher</span>
        </div>
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight">
          ✨ AI Opportunity <span className="text-gradient">Matcher</span>
        </h1>
        <p className="text-sm sm:text-base text-[#94a3b8] leading-relaxed max-w-xl mx-auto">
          Describe your background, skills, preferred event type, and prize targets in plain English. Our AI matcher will formulate personalized recommendations.
        </p>
      </div>

      {/* Query Box Form */}
      <div className="max-w-3xl mx-auto">
        <form
          onSubmit={handleFormSubmit}
          className="p-3 rounded-2xl bg-[#172033] border border-[#334155] shadow-2xl shadow-purple-950/40 focus-within:border-[#7c3aed] transition-all space-y-3"
        >
          <div className="relative">
            <textarea
              rows={3}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="e.g. I am a 3rd year CS student looking for online AI hackathons with high prize pools..."
              className="w-full bg-transparent p-3 text-sm text-white placeholder-[#94a3b8] focus:outline-none resize-none leading-relaxed"
            />
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-[#334155]/60">
            <span className="text-xs text-[#94a3b8] flex items-center gap-1.5">
              <Bot className="w-3.5 h-3.5 text-cyan-400" />
              <span>Natural language query parsing engine</span>
            </span>

            <button
              type="submit"
              disabled={loading || !query.trim()}
              className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#7c3aed] to-[#06b6d4] hover:from-[#6d28d9] hover:to-[#0891b2] text-white text-xs sm:text-sm font-bold transition-all shadow-lg shadow-purple-600/25 active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>Find My Best Matches</span>
            </button>
          </div>
        </form>

        {/* Sample Prompt Chips */}
        <div className="mt-4 space-y-2">
          <span className="text-[11px] font-semibold text-[#94a3b8] uppercase tracking-wider block">
            Try Sample Prompts:
          </span>
          <div className="flex items-center gap-2 flex-wrap">
            {samplePrompts.map((sample) => (
              <button
                key={sample}
                type="button"
                onClick={() => handleMatch(sample)}
                className="text-xs px-3 py-1.5 rounded-xl bg-[#1e293b] hover:bg-[#334155] text-slate-300 hover:text-white border border-[#334155] transition-colors text-left"
              >
                "{sample}"
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Loading state */}
      {loading && (
        <div className="py-12">
          <LoadingSpinner size="lg" label="Analyzing intent and querying matching opportunities..." />
        </div>
      )}

      {/* Results Section */}
      {!loading && analysis && (
        <div className="space-y-8 animate-in fade-in duration-300">
          
          {/* AI Criteria Extraction & Reasoning Card */}
          <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-purple-950/40 via-[#172033] to-cyan-950/30 border border-[#7c3aed]/40 space-y-5">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-[#7c3aed]/20 text-[#c084fc]">
                  <Bot className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">AI Query Decomposition</h3>
                  <p className="text-xs text-[#94a3b8]">Extracted semantic intent from your prompt</p>
                </div>
              </div>
              <span className="text-xs font-semibold px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                Confidence: High (96%)
              </span>
            </div>

            {/* Extracted Criteria Badges */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
              <div className="p-3 rounded-xl bg-[#1e293b]/70 border border-[#334155]">
                <span className="text-[11px] text-[#94a3b8] block">Audience Target</span>
                <span className="text-xs font-bold text-white capitalize">
                  {analysis.extractedCriteria.audience || 'Any Student / Open'}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-[#1e293b]/70 border border-[#334155]">
                <span className="text-[11px] text-[#94a3b8] block">Specialization</span>
                <span className="text-xs font-bold text-cyan-300 capitalize">
                  {analysis.extractedCriteria.category || 'General Software'}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-[#1e293b]/70 border border-[#334155]">
                <span className="text-[11px] text-[#94a3b8] block">Format / Mode</span>
                <span className="text-xs font-bold text-purple-300 capitalize">
                  {analysis.extractedCriteria.mode || 'Online / Any'}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-[#1e293b]/70 border border-[#334155]">
                <span className="text-[11px] text-[#94a3b8] block">Event Format</span>
                <span className="text-xs font-bold text-emerald-300 capitalize">
                  {analysis.extractedCriteria.type || 'Hackathon'}
                </span>
              </div>
            </div>

            {/* AI Explanation Paragraph */}
            <div className="p-4 rounded-xl bg-black/30 border border-[#334155]/60 text-xs sm:text-sm text-[#cbd5e1] leading-relaxed flex items-start gap-3">
              <Sparkles className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
              <p>{analysis.reasoning}</p>
            </div>
          </div>

          {/* Matched Opportunities Grid */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-white">
                Matched Opportunities ({analysis.matchedEvents.length})
              </h2>
              <span className="text-xs text-[#94a3b8]">Sorted by semantic relevance score</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {analysis.matchedEvents.map((event) => (
                <EventCard key={event.id} event={event} />
              ))}
            </div>

            {analysis.matchedEvents.length === 0 && (
              <div className="p-12 text-center rounded-2xl bg-[#172033] border border-[#334155] max-w-md mx-auto">
                <p className="text-sm text-slate-300">
                  No exact matches found for this specific query. Try broadening your criteria or selecting a sample prompt.
                </p>
              </div>
            )}
          </div>

        </div>
      )}

    </div>
  );
};
