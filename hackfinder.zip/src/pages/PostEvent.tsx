import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  PlusCircle,
  CheckCircle2,
  Calendar,
  MapPin,
  Trophy,
  Sparkles,
  ArrowRight,
  Upload,
  Globe,
  DollarSign
} from 'lucide-react';
import { addEvent } from '../utils/storage';
import { EventItem } from '../types';
import { EVENT_CATEGORIES } from '../data/events';

const SAMPLE_IMAGES = [
  'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1515187029135-18ee286d815b?auto=format&fit=crop&w=1200&q=80',
];

export const PostEvent: React.FC = () => {
  const navigate = useNavigate();
  const [submittedEventId, setSubmittedEventId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    type: 'hackathon' as EventItem['type'],
    organization: '',
    category: 'Artificial Intelligence',
    description: '',
    about: '',
    image: SAMPLE_IMAGES[0],
    mode: 'Online' as EventItem['mode'],
    city: '',
    country: 'India',
    startDate: '2026-10-15',
    endDate: '2026-10-17',
    registrationDeadline: '2026-10-05',
    prizeAmount: 100000,
    currency: 'INR',
    costType: 'free' as EventItem['costType'],
    registrationUrl: 'https://example.com/register',
    tracks: 'AI Agents, LLMs, Computer Vision',
    domains: 'Artificial Intelligence, Software Development',
    eligibility: 'Open to college students and working software developers worldwide.'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.organization) return;

    const newId = `user-event-${Date.now()}`;
    const newEvent: EventItem = {
      id: newId,
      title: formData.title,
      type: formData.type,
      organization: formData.organization,
      category: formData.category,
      description: formData.description || 'Join builders and innovators to solve cutting-edge challenges.',
      about: formData.about || formData.description,
      image: formData.image,
      mode: formData.mode,
      city: formData.mode === 'Online' ? undefined : formData.city,
      country: formData.country,
      startDate: formData.startDate,
      endDate: formData.endDate,
      registrationDeadline: formData.registrationDeadline,
      prizeAmount: Number(formData.prizeAmount) || 0,
      currency: formData.currency,
      costType: formData.costType,
      registrationUrl: formData.registrationUrl,
      domains: formData.domains.split(',').map((s) => s.trim()).filter(Boolean),
      tracks: formData.tracks.split(',').map((s) => s.trim()).filter(Boolean),
      eligibility: formData.eligibility,
      submissionType: 'Working software prototype and pitch deck',
      benefits: ['Cash rewards', 'Official verifiable certificate', 'Networking with founders'],
      timeline: [
        { stage: 'Registration Opens', date: 'Open Now', status: 'completed' },
        { stage: 'Registration Deadline', date: formData.registrationDeadline, status: 'current' },
        { stage: 'Event Starts', date: formData.startDate, status: 'upcoming' },
        { stage: 'Grand Finale & Demos', date: formData.endDate, status: 'upcoming' },
      ],
      featured: false,
      trending: true,
      verified: false,
      viewsCount: 1,
      savedCount: 0,
      createdAt: new Date().toISOString()
    };

    addEvent(newEvent);
    setSubmittedEventId(newId);
  };

  if (submittedEventId) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center space-y-6">
        <div className="w-16 h-16 rounded-3xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center mx-auto shadow-lg shadow-emerald-950/40">
          <CheckCircle2 className="w-8 h-8" />
        </div>
        <h2 className="text-3xl font-extrabold text-white">Event Posted Successfully!</h2>
        <p className="text-sm text-[#94a3b8] max-w-md mx-auto leading-relaxed">
          Your opportunity has been published to HackFinder and is now discoverable across the Explore and Search feeds.
        </p>
        <div className="flex items-center justify-center gap-3 pt-4">
          <Link
            to={`/events/${submittedEventId}`}
            className="px-6 py-3 rounded-xl bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-sm font-bold shadow-lg shadow-purple-600/30 flex items-center gap-2"
          >
            <span>View Published Event</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
          <button
            onClick={() => {
              setSubmittedEventId(null);
              setFormData((prev) => ({ ...prev, title: '', organization: '' }));
            }}
            className="px-5 py-3 rounded-xl bg-[#1e293b] text-slate-300 text-sm font-semibold hover:text-white"
          >
            Post Another Event
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      
      {/* Header */}
      <div className="space-y-2 pb-6 border-b border-[#334155]/60">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-purple-500/15 text-[#c084fc] border border-purple-500/30">
          <PlusCircle className="w-3.5 h-3.5 text-[#a78bfa]" />
          <span>Organizer Submission Portal</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          Post an Opportunity
        </h1>
        <p className="text-sm text-[#94a3b8] leading-relaxed">
          Publish your hackathon, tech conference, symposium, workshop, or pitch contest to thousands of curious developers and builders.
        </p>
      </div>

      {/* Main Form */}
      <form onSubmit={handleSubmit} className="space-y-8">
        
        {/* Section 1: Basic Information */}
        <div className="p-6 sm:p-8 rounded-3xl bg-[#172033]/80 border border-[#334155] space-y-5">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span>1. Basic Details</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Event Title *
              </label>
              <input
                type="text"
                required
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="e.g. NextGen AI Hackathon 2026"
                className="w-full px-4 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-sm focus:outline-none focus:border-[#7c3aed]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Event Type *
              </label>
              <select
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
                className="w-full px-4 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-sm focus:outline-none focus:border-[#7c3aed]"
              >
                <option value="hackathon">Hackathon</option>
                <option value="conference">Conference</option>
                <option value="symposium">Symposium</option>
                <option value="workshop">Workshop</option>
                <option value="certification">Certification</option>
                <option value="fellowship">Fellowship</option>
                <option value="pitch">Pitch Contest</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Organization / Host *
              </label>
              <input
                type="text"
                required
                value={formData.organization}
                onChange={(e) => setFormData({ ...formData, organization: e.target.value })}
                placeholder="e.g. Stanford AI Lab or DevFolio"
                className="w-full px-4 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-sm focus:outline-none focus:border-[#7c3aed]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Category / Domain *
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-sm focus:outline-none focus:border-[#7c3aed]"
              >
                {EVENT_CATEGORIES.filter((c) => c.id !== 'all').map((cat) => (
                  <option key={cat.id} value={cat.name}>
                    {cat.emoji} {cat.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Registration Cost *
              </label>
              <select
                value={formData.costType}
                onChange={(e) => setFormData({ ...formData, costType: e.target.value as any })}
                className="w-full px-4 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-sm focus:outline-none focus:border-[#7c3aed]"
              >
                <option value="free">Free Entry</option>
                <option value="paid">Paid Registration</option>
                <option value="scholarship">Scholarships Available</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Short Overview / Tagline
              </label>
              <textarea
                rows={2}
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Brief summary appearing on event cards..."
                className="w-full px-4 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-sm focus:outline-none focus:border-[#7c3aed]"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Detailed About Section
              </label>
              <textarea
                rows={4}
                value={formData.about}
                onChange={(e) => setFormData({ ...formData, about: e.target.value })}
                placeholder="Elaborate details on challenge statements, rules, team sizes, and schedule..."
                className="w-full px-4 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-sm focus:outline-none focus:border-[#7c3aed]"
              />
            </div>
          </div>

          {/* Banner Image selector */}
          <div className="space-y-2 pt-2">
            <label className="block text-xs font-semibold text-slate-300">
              Select Banner Preview or Custom Image URL
            </label>
            <div className="grid grid-cols-5 gap-2">
              {SAMPLE_IMAGES.map((imgUrl, i) => (
                <button
                  key={imgUrl}
                  type="button"
                  onClick={() => setFormData({ ...formData, image: imgUrl })}
                  className={`h-16 rounded-xl overflow-hidden border-2 transition-all ${
                    formData.image === imgUrl ? 'border-[#7c3aed] ring-2 ring-purple-500/40' : 'border-[#334155] opacity-60'
                  }`}
                >
                  <img src={imgUrl} alt={`Preset ${i + 1}`} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
            <input
              type="url"
              value={formData.image}
              onChange={(e) => setFormData({ ...formData, image: e.target.value })}
              placeholder="Or paste custom image URL..."
              className="w-full px-3 py-2 rounded-xl bg-[#0f172a] border border-[#334155] text-xs text-white"
            />
          </div>
        </div>

        {/* Section 2: Mode & Location */}
        <div className="p-6 sm:p-8 rounded-3xl bg-[#172033]/80 border border-[#334155] space-y-5">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Globe className="w-4 h-4 text-cyan-400" />
            <span>2. Mode & Location</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Mode *</label>
              <select
                value={formData.mode}
                onChange={(e) => setFormData({ ...formData, mode: e.target.value as any })}
                className="w-full px-4 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-sm focus:outline-none focus:border-[#7c3aed]"
              >
                <option value="Online">Online / Virtual</option>
                <option value="Offline">Offline / In-Person</option>
                <option value="Hybrid">Hybrid</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">City (if in-person)</label>
              <input
                type="text"
                disabled={formData.mode === 'Online'}
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                placeholder="e.g. Bengaluru"
                className="w-full px-4 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-sm focus:outline-none focus:border-[#7c3aed] disabled:opacity-40"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Country *</label>
              <input
                type="text"
                value={formData.country}
                onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                placeholder="e.g. India or Global"
                className="w-full px-4 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-sm focus:outline-none focus:border-[#7c3aed]"
              />
            </div>
          </div>
        </div>

        {/* Section 3: Dates & Registration */}
        <div className="p-6 sm:p-8 rounded-3xl bg-[#172033]/80 border border-[#334155] space-y-5">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Calendar className="w-4 h-4 text-cyan-400" />
            <span>3. Dates & Deadlines</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Registration Deadline *
              </label>
              <input
                type="date"
                required
                value={formData.registrationDeadline}
                onChange={(e) => setFormData({ ...formData, registrationDeadline: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-sm focus:outline-none focus:border-[#7c3aed]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Start Date *
              </label>
              <input
                type="date"
                required
                value={formData.startDate}
                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-sm focus:outline-none focus:border-[#7c3aed]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                End Date *
              </label>
              <input
                type="date"
                required
                value={formData.endDate}
                onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-sm focus:outline-none focus:border-[#7c3aed]"
              />
            </div>
          </div>
        </div>

        {/* Section 4: Prizes & Links */}
        <div className="p-6 sm:p-8 rounded-3xl bg-[#172033]/80 border border-[#334155] space-y-5">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>4. Prize Pool & Registration Link</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Total Prize Pool Value (in INR)
              </label>
              <input
                type="number"
                value={formData.prizeAmount}
                onChange={(e) => setFormData({ ...formData, prizeAmount: Number(e.target.value) })}
                placeholder="100000"
                className="w-full px-4 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-sm focus:outline-none focus:border-[#7c3aed]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                External Registration URL *
              </label>
              <input
                type="url"
                required
                value={formData.registrationUrl}
                onChange={(e) => setFormData({ ...formData, registrationUrl: e.target.value })}
                placeholder="https://devfolio.co/my-hackathon"
                className="w-full px-4 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-sm focus:outline-none focus:border-[#7c3aed]"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Tracks / Challenge Categories (comma separated)
              </label>
              <input
                type="text"
                value={formData.tracks}
                onChange={(e) => setFormData({ ...formData, tracks: e.target.value })}
                placeholder="Generative AI, Web3, FinTech, Open Innovation"
                className="w-full px-4 py-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white text-sm focus:outline-none focus:border-[#7c3aed]"
              />
            </div>
          </div>
        </div>

        {/* Submit button bar */}
        <div className="flex items-center justify-end gap-3 pt-4">
          <Link
            to="/events"
            className="px-6 py-3 rounded-xl bg-[#1e293b] text-slate-300 font-semibold text-sm hover:text-white"
          >
            Cancel
          </Link>
          <button
            type="submit"
            className="px-8 py-3.5 rounded-xl bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-sm font-bold shadow-xl shadow-purple-600/30 transition-all active:scale-95 flex items-center gap-2"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Publish Opportunity</span>
          </button>
        </div>

      </form>

    </div>
  );
};
