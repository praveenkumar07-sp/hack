import React, { useState, useMemo } from 'react';
import { Flame, Bookmark, Clock, Trophy, Globe, Sparkles } from 'lucide-react';
import { getAllEvents } from '../utils/storage';
import { EventGrid } from '../components/EventGrid';
import { getEventStatus } from '../utils/filters';

type TrendingTab = 'mostSaved' | 'closingSoon' | 'highestPrize' | 'global';

export const Trending: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TrendingTab>('mostSaved');
  const allEvents = getAllEvents();

  const filteredList = useMemo(() => {
    switch (activeTab) {
      case 'mostSaved':
        // Sort by viewsCount / popularity
        return [...allEvents]
          .sort((a, b) => (b.viewsCount || 0) - (a.viewsCount || 0))
          .slice(0, 12);
      case 'closingSoon':
        return allEvents.filter((e) => {
          const { isClosingSoon } = getEventStatus(e);
          return isClosingSoon;
        });
      case 'highestPrize':
        return [...allEvents]
          .sort((a, b) => b.prizeAmount - a.prizeAmount)
          .slice(0, 12);
      case 'global':
        return allEvents.filter(
          (e) => e.mode === 'Online' || e.country.toLowerCase().includes('global')
        );
      default:
        return allEvents;
    }
  }, [allEvents, activeTab]);

  const tabs = [
    { id: 'mostSaved', label: '🔥 Most Saved & Popular', icon: Bookmark },
    { id: 'closingSoon', label: '⚡ Closing Soon', icon: Clock },
    { id: 'highestPrize', label: '🏆 Highest Prize Pools', icon: Trophy },
    { id: 'global', label: '🌎 Global / Online', icon: Globe },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      
      {/* Header */}
      <div className="max-w-2xl space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-rose-500/15 text-rose-300 border border-rose-500/30">
          <Flame className="w-3.5 h-3.5 text-rose-400" />
          <span>Community Radar</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          Trending Opportunities
        </h1>
        <p className="text-sm text-[#94a3b8] leading-relaxed">
          Discover what the HackFinder community is exploring, saving, and preparing for right now.
        </p>
      </div>

      {/* Tabs Row */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-[#334155]">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as TrendingTab)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-[#7c3aed] text-white shadow-md shadow-purple-600/30'
                  : 'bg-[#172033] hover:bg-[#1e293b] text-slate-300 border border-[#334155]'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Results Header */}
      <div className="flex items-center justify-between text-xs text-[#94a3b8]">
        <span>Showing {filteredList.length} trending items</span>
        <span className="text-slate-400">Refreshed live from community bookmarks</span>
      </div>

      {/* Event Grid */}
      <EventGrid
        events={filteredList}
        emptyTitle="No trending events in this category"
        emptyDescription="Check out the other trending tabs to discover high-profile opportunities."
      />

    </div>
  );
};
