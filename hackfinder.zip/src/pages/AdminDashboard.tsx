import React, { useState } from 'react';
import {
  ShieldCheck,
  CheckCircle,
  XCircle,
  Star,
  Trash2,
  Calendar,
  Building2,
  ExternalLink,
  Search,
  Filter,
  PlusCircle,
  RotateCcw
} from 'lucide-react';
import { getAllEvents, saveAllEvents, resetDefaultEvents } from '../utils/storage';
import { EventItem } from '../types';
import { Link } from 'react-router-dom';

export const AdminDashboard: React.FC = () => {
  const [events, setEvents] = useState<EventItem[]>(() => getAllEvents());
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState('all');

  const handleToggleVerified = (id: string) => {
    const updated = events.map((e) =>
      e.id === id ? { ...e, verified: !e.verified } : e
    );
    setEvents(updated);
    saveAllEvents(updated);
  };

  const handleToggleFeatured = (id: string) => {
    const updated = events.map((e) =>
      e.id === id ? { ...e, featured: !e.featured } : e
    );
    setEvents(updated);
    saveAllEvents(updated);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this event from HackFinder?')) {
      const updated = events.filter((e) => e.id !== id);
      setEvents(updated);
      saveAllEvents(updated);
    }
  };

  const handleResetData = () => {
    if (window.confirm('Reset all mock events to factory default catalog?')) {
      const reset = resetDefaultEvents();
      setEvents(reset);
    }
  };

  const filteredEvents = events.filter((e) => {
    const matchesSearch =
      e.title.toLowerCase().includes(search.toLowerCase()) ||
      e.organization.toLowerCase().includes(search.toLowerCase()) ||
      e.category.toLowerCase().includes(search.toLowerCase());
    const matchesType = filterType === 'all' || e.type === filterType;
    return matchesSearch && matchesType;
  });

  const verifiedCount = events.filter((e) => e.verified).length;
  const featuredCount = events.filter((e) => e.featured).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-[#334155]/60">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Platform Administration</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Admin Verification Portal
          </h1>
          <p className="text-sm text-[#94a3b8] leading-relaxed">
            Verify organizer legitimacy, manage featured event slots, and moderate community submissions.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleResetData}
            className="px-3.5 py-2 rounded-xl bg-[#1e293b] hover:bg-[#334155] text-slate-300 text-xs font-semibold border border-[#334155] flex items-center gap-1.5 transition-colors"
            title="Reset to initial 26 mock events"
          >
            <RotateCcw className="w-3.5 h-3.5 text-cyan-400" />
            <span>Reset Demo Data</span>
          </button>
          <Link
            to="/post-event"
            className="px-4 py-2 rounded-xl bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-xs font-semibold shadow-md shadow-purple-600/30 flex items-center gap-1.5"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Add Event</span>
          </Link>
        </div>
      </div>

      {/* Admin Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-[#172033]/80 border border-[#334155] flex items-center justify-between">
          <div>
            <span className="text-xs font-medium text-[#94a3b8]">Total Listed Events</span>
            <span className="text-2xl font-extrabold text-white block mt-1">{events.length}</span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-[#1e293b] flex items-center justify-center text-cyan-400">
            <Calendar className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#172033]/80 border border-[#334155] flex items-center justify-between">
          <div>
            <span className="text-xs font-medium text-[#94a3b8]">Verified Events</span>
            <span className="text-2xl font-extrabold text-emerald-400 block mt-1">{verifiedCount}</span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-500/15 flex items-center justify-center text-emerald-400">
            <CheckCircle className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#172033]/80 border border-[#334155] flex items-center justify-between">
          <div>
            <span className="text-xs font-medium text-[#94a3b8]">Featured on Homepage</span>
            <span className="text-2xl font-extrabold text-amber-400 block mt-1">{featuredCount}</span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-500/15 flex items-center justify-center text-amber-400">
            <Star className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Filters & Search Toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
        <div className="relative flex-1 w-full max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-[#94a3b8]" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Filter by title, host organization, or category..."
            className="w-full pl-10 pr-4 py-2 text-xs rounded-xl bg-[#172033] border border-[#334155] text-white placeholder-[#94a3b8] focus:outline-none focus:border-[#7c3aed]"
          />
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-3 py-2 rounded-xl bg-[#172033] border border-[#334155] text-xs text-white focus:outline-none"
          >
            <option value="all">All Types</option>
            <option value="hackathon">Hackathons</option>
            <option value="conference">Conferences</option>
            <option value="workshop">Workshops</option>
            <option value="fellowship">Fellowships</option>
          </select>
        </div>
      </div>

      {/* Event Moderation Table */}
      <div className="rounded-2xl bg-[#172033]/80 border border-[#334155] overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#1e293b] text-[#94a3b8] uppercase font-semibold tracking-wider border-b border-[#334155]">
              <tr>
                <th className="py-3.5 px-4">Event Details</th>
                <th className="py-3.5 px-4">Organization</th>
                <th className="py-3.5 px-4">Category</th>
                <th className="py-3.5 px-4">Type</th>
                <th className="py-3.5 px-4">Deadline</th>
                <th className="py-3.5 px-4 text-center">Status & Badges</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#334155]/60 text-slate-200">
              {filteredEvents.map((e) => (
                <tr key={e.id} className="hover:bg-[#1e293b]/40 transition-colors">
                  <td className="py-3.5 px-4 max-w-xs">
                    <div className="flex items-center gap-3">
                      <img
                        src={e.image}
                        alt=""
                        className="w-10 h-10 rounded-lg object-cover border border-[#334155] shrink-0"
                      />
                      <div className="overflow-hidden">
                        <Link
                          to={`/events/${e.id}`}
                          className="font-bold text-white hover:text-cyan-400 transition-colors truncate block"
                        >
                          {e.title}
                        </Link>
                        <span className="text-[11px] text-[#94a3b8]">{e.mode}</span>
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 font-medium text-slate-300">
                    {e.organization}
                  </td>
                  <td className="py-3.5 px-4 text-cyan-300">
                    {e.category}
                  </td>
                  <td className="py-3.5 px-4 uppercase font-semibold text-purple-300">
                    {e.type}
                  </td>
                  <td className="py-3.5 px-4 text-[#94a3b8] whitespace-nowrap">
                    {e.registrationDeadline}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="flex items-center justify-center gap-2">
                      <button
                        onClick={() => handleToggleVerified(e.id)}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-bold border transition-colors ${
                          e.verified
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                            : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                        }`}
                        title="Toggle verification status"
                      >
                        {e.verified ? '✓ Verified' : 'Unverified'}
                      </button>

                      <button
                        onClick={() => handleToggleFeatured(e.id)}
                        className={`p-1.5 rounded-md border transition-colors ${
                          e.featured
                            ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                            : 'bg-slate-800 text-slate-500 border-slate-700 hover:text-amber-300'
                        }`}
                        title="Toggle featured flag"
                      >
                        <Star className={`w-3.5 h-3.5 ${e.featured ? 'fill-current' : ''}`} />
                      </button>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Link
                        to={`/events/${e.id}`}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#1e293b]"
                        title="View Public Page"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </Link>
                      <button
                        onClick={() => handleDelete(e.id)}
                        className="p-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 transition-colors"
                        title="Delete Event"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredEvents.length === 0 && (
          <div className="p-8 text-center text-xs text-[#94a3b8]">
            No events match your current filter criteria.
          </div>
        )}
      </div>

    </div>
  );
};
