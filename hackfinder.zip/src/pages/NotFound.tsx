import React from 'react';
import { Link } from 'react-router-dom';
import { Compass, ArrowRight } from 'lucide-react';

export const NotFound: React.FC = () => {
  return (
    <div className="min-h-[70vh] flex flex-col items-center justify-center px-4 py-16 text-center space-y-5">
      <div className="w-20 h-20 rounded-3xl bg-[#172033] border border-[#334155] flex items-center justify-center text-[#c084fc] shadow-2xl">
        <Compass className="w-10 h-10 animate-spin" style={{ animationDuration: '12s' }} />
      </div>
      <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
        404 — Page Not Found
      </h1>
      <p className="text-sm text-[#94a3b8] max-w-md mx-auto leading-relaxed">
        The route you are looking for has moved or does not exist. Let's get you back on track to discover hackathons and conferences.
      </p>
      <div className="pt-2">
        <Link
          to="/"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-sm font-bold shadow-lg shadow-purple-600/30 transition-all active:scale-95"
        >
          <span>Return to Homepage</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
};
