import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Filter, SlidersHorizontal, ArrowUpDown, Sparkles, RotateCcw } from 'lucide-react';
import { SearchBar } from '../components/SearchBar';
import { FilterSidebar } from '../components/FilterSidebar';
import { EventGrid } from '../components/EventGrid';
import { getAllEvents } from '../utils/storage';
import { filterEvents, FilterOptions } from '../utils/filters';

export const Events: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();

  const [allEvents, setAllEvents] = useState(() => getAllEvents());
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  // Initialize filters from query params
  const [filters, setFilters] = useState<FilterOptions>(() => {
    const search = searchParams.get('search') || '';
    const category = searchParams.get('category');
    const type = searchParams.get('type');
    const filterFlag = searchParams.get('filter');

    return {
      search,
      categories: category ? [category] : [],
      types: type ? [type] : [],
      closingSoonOnly: filterFlag === 'closingSoon',
      featuredOnly: filterFlag === 'featured',
      trendingOnly: filterFlag === 'trending',
      sortBy: 'popularity',
      minPrize: 0
    };
  });

  // Keep search param sync
  useEffect(() => {
    const q = searchParams.get('search');
    const cat = searchParams.get('category');
    const type = searchParams.get('type');
    const flag = searchParams.get('filter');

    setFilters(prev => ({
      ...prev,
      search: q !== null ? q : prev.search,
      categories: cat ? [cat] : prev.categories,
      types: type ? [type] : prev.types,
      closingSoonOnly: flag === 'closingSoon' ? true : prev.closingSoonOnly,
      featuredOnly: flag === 'featured' ? true : prev.featuredOnly,
      trendingOnly: flag === 'trending' ? true : prev.trendingOnly,
    }));
  }, [searchParams]);

  // Compute filtered events
  const filteredEvents = useMemo(() => {
    return filterEvents(allEvents, filters);
  }, [allEvents, filters]);

  const handleSearchChange = (val: string) => {
    setFilters(prev => ({ ...prev, search: val }));
  };

  const handleClearFilters = () => {
    setFilters({
      search: '',
      types: [],
      modes: [],
      categories: [],
      audience: [],
      costs: [],
      minPrize: 0,
      sortBy: 'popularity',
      closingSoonOnly: false,
      featuredOnly: false,
      trendingOnly: false
    });
    setSearchParams({});
  };

  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFilters(prev => ({ ...prev, sortBy: e.target.value as any }));
  };

  const activeFilterCount =
    (filters.types?.length || 0) +
    (filters.modes?.length || 0) +
    (filters.categories?.length || 0) +
    (filters.audience?.length || 0) +
    (filters.costs?.length || 0) +
    (filters.minPrize && filters.minPrize > 0 ? 1 : 0) +
    (filters.closingSoonOnly ? 1 : 0) +
    (filters.featuredOnly ? 1 : 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-[#334155]/60">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-[#7c3aed]/15 text-[#c084fc] border border-[#7c3aed]/30 mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Discover Opportunities</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Explore Opportunities
          </h1>
          <p className="text-sm text-[#94a3b8] mt-1.5 max-w-xl">
            Discover hackathons, conferences, certifications, and technical events that match your goals and ambition.
          </p>
        </div>

        {/* Total found badge */}
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold text-slate-300">
            <span className="text-cyan-400 font-bold">{filteredEvents.length}</span> opportunities found
          </span>
        </div>
      </div>

      {/* Top Search & Mobile Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="flex-1 w-full">
          <SearchBar
            value={filters.search || ''}
            onChange={handleSearchChange}
            placeholder="🔍 Search events, organizations, domains, technologies..."
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto shrink-0 justify-between sm:justify-start">
          {/* Mobile Filter Trigger Button */}
          <button
            onClick={() => setMobileFilterOpen(true)}
            className="lg:hidden flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-[#172033] hover:bg-[#1e293b] border border-[#334155] text-sm font-semibold text-white transition-colors"
          >
            <SlidersHorizontal className="w-4 h-4 text-cyan-400" />
            <span>Filters</span>
            {activeFilterCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-[#7c3aed] text-white text-xs flex items-center justify-center font-bold">
                {activeFilterCount}
              </span>
            )}
          </button>

          {/* Sort Dropdown */}
          <div className="relative flex-1 sm:flex-none flex items-center rounded-xl bg-[#172033] border border-[#334155] px-3 py-2.5">
            <ArrowUpDown className="w-4 h-4 text-[#94a3b8] mr-2 shrink-0" />
            <select
              value={filters.sortBy || 'popularity'}
              onChange={handleSortChange}
              className="bg-transparent text-xs sm:text-sm font-medium text-[#f8fafc] focus:outline-none cursor-pointer pr-4"
            >
              <option value="popularity" className="bg-[#172033] text-white">Sort by: Popularity</option>
              <option value="newest" className="bg-[#172033] text-white">Sort by: Newest</option>
              <option value="deadline" className="bg-[#172033] text-white">Sort by: Deadline</option>
              <option value="prize" className="bg-[#172033] text-white">Sort by: Prize Pool</option>
            </select>
          </div>
        </div>
      </div>

      {/* Active Filter Pills Bar */}
      {activeFilterCount > 0 && (
        <div className="flex items-center gap-2 flex-wrap text-xs pt-1">
          <span className="text-[#94a3b8]">Active Filters:</span>
          {filters.categories?.map(c => (
            <span key={c} className="px-2.5 py-1 rounded-lg bg-[#1e293b] text-cyan-300 border border-[#334155] flex items-center gap-1.5">
              <span>{c}</span>
              <button
                onClick={() => setFilters(prev => ({ ...prev, categories: prev.categories?.filter(item => item !== c) }))}
                className="hover:text-white"
              >
                ×
              </button>
            </span>
          ))}
          {filters.types?.map(t => (
            <span key={t} className="px-2.5 py-1 rounded-lg bg-[#1e293b] text-purple-300 border border-[#334155] capitalize flex items-center gap-1.5">
              <span>{t}</span>
              <button
                onClick={() => setFilters(prev => ({ ...prev, types: prev.types?.filter(item => item !== t) }))}
                className="hover:text-white"
              >
                ×
              </button>
            </span>
          ))}
          {filters.modes?.map(m => (
            <span key={m} className="px-2.5 py-1 rounded-lg bg-[#1e293b] text-emerald-300 border border-[#334155] flex items-center gap-1.5">
              <span>{m}</span>
              <button
                onClick={() => setFilters(prev => ({ ...prev, modes: prev.modes?.filter(item => item !== m) }))}
                className="hover:text-white"
              >
                ×
              </button>
            </span>
          ))}
          {filters.minPrize && filters.minPrize > 0 ? (
            <span className="px-2.5 py-1 rounded-lg bg-[#1e293b] text-amber-300 border border-[#334155] flex items-center gap-1.5">
              <span>Prize &gt; ₹{filters.minPrize.toLocaleString('en-IN')}</span>
              <button
                onClick={() => setFilters(prev => ({ ...prev, minPrize: 0 }))}
                className="hover:text-white"
              >
                ×
              </button>
            </span>
          ) : null}
          {filters.closingSoonOnly && (
            <span className="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1.5">
              <span>Closing Soon</span>
              <button onClick={() => setFilters(prev => ({ ...prev, closingSoonOnly: false }))} className="hover:text-white">×</button>
            </span>
          )}
          <button
            onClick={handleClearFilters}
            className="text-xs text-rose-400 hover:text-rose-300 underline font-medium ml-2"
          >
            Reset All
          </button>
        </div>
      )}

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 items-start">
        
        {/* Desktop Filter Sidebar */}
        <div className="hidden lg:block lg:col-span-1">
          <FilterSidebar
            filters={filters}
            onChange={setFilters}
            onClear={handleClearFilters}
            totalCount={filteredEvents.length}
          />
        </div>

        {/* Mobile Filter Drawer */}
        <FilterSidebar
          isMobileDrawer
          isOpenMobile={mobileFilterOpen}
          onCloseMobile={() => setMobileFilterOpen(false)}
          filters={filters}
          onChange={setFilters}
          onClear={handleClearFilters}
          totalCount={filteredEvents.length}
        />

        {/* Events Cards Grid */}
        <div className="lg:col-span-3 space-y-6">
          <EventGrid
            events={filteredEvents}
            emptyTitle="No matching opportunities found"
            emptyDescription="No events match your current search terms or selected filters. Try clearing your filters to explore all available opportunities."
            emptyActionText="Clear All Filters"
            onSaveToggle={() => setAllEvents(getAllEvents())}
          />
        </div>

      </div>

    </div>
  );
};
