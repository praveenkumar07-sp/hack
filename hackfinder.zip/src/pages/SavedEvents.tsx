import React, { useState, useEffect } from 'react';
import { Bookmark, Sparkles, Trash2, ArrowRight } from 'lucide-react';
import { getSavedEventIds, getAllEvents, clearAllSavedEvents } from '../utils/storage';
import { EventCard } from '../components/EventCard';
import { EmptyState } from '../components/EmptyState';

export const SavedEvents: React.FC = () => {
  const [savedIds, setSavedIds] = useState<string[]>(() => getSavedEventIds());
  const allEvents = getAllEvents();

  useEffect(() => {
    const sync = () => setSavedIds(getSavedEventIds());
    window.addEventListener('storage', sync);
    return () => window.removeEventListener('storage', sync);
  }, []);

  const savedEvents = allEvents.filter((e) => savedIds.includes(e.id));

  const handleSaveToggle = (id: string, isSaved: boolean) => {
    if (!isSaved) {
      setSavedIds(prev => prev.filter(savedId => savedId !== id));
    }
  };

  const handleClearAll = () => {
    if (window.confirm('Are you sure you want to remove all saved opportunities?')) {
      clearAllSavedEvents();
      setSavedIds([]);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-[#334155]/60">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-purple-500/15 text-[#c084fc] border border-purple-500/30">
            <Bookmark className="w-3.5 h-3.5" />
            <span>Personal Bookmarks</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Saved Opportunities
          </h1>
          <p className="text-sm text-[#94a3b8] leading-relaxed max-w-xl">
            Keep track of upcoming deadlines, prepare project repositories, and never miss an important submission date.
          </p>
        </div>

        {savedEvents.length > 0 && (
          <div className="flex items-center gap-3">
            <span className="text-xs text-slate-300 font-semibold px-3 py-1.5 rounded-xl bg-[#172033] border border-[#334155]">
              {savedEvents.length} bookmarked
            </span>
            <button
              onClick={handleClearAll}
              className="text-xs text-rose-400 hover:text-rose-300 transition-colors flex items-center gap-1 px-3 py-1.5 rounded-xl bg-rose-500/10 border border-rose-500/20"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear All</span>
            </button>
          </div>
        )}
      </div>

      {/* Content */}
      {savedEvents.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {savedEvents.map((event) => (
            <EventCard key={event.id} event={event} onSaveToggle={handleSaveToggle} />
          ))}
        </div>
      ) : (
        <EmptyState
          icon={<Bookmark className="w-8 h-8 text-[#a78bfa]" />}
          title="You haven't saved any events yet"
          description="Explore our curated catalog of hackathons, workshops, and conferences, and tap the bookmark icon on any card to save it here."
          actionText="Explore Opportunities"
          actionHref="/events"
        />
      )}

    </div>
  );
};
