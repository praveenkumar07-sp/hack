import React, { useState } from 'react';
import {
  Users,
  Search,
  PlusCircle,
  GraduationCap,
  Calendar,
  MessageSquare,
  CheckCircle,
  Sparkles,
  Send,
  X
} from 'lucide-react';
import { getTeammateRequests, saveTeammateRequest } from '../utils/storage';
import { TeammateRequest } from '../types';
import { Modal } from '../components/Modal';

export const Teammates: React.FC = () => {
  const [requests, setRequests] = useState<TeammateRequest[]>(() => getTeammateRequests());
  const [searchTerm, setSearchTerm] = useState('');
  const [postModalOpen, setPostModalOpen] = useState(false);
  const [connectModalRequest, setConnectModalRequest] = useState<TeammateRequest | null>(null);
  const [connectMessageSent, setConnectMessageSent] = useState(false);

  // New Request Form State
  const [formData, setFormData] = useState({
    name: '',
    role: '',
    university: '',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    eventName: '',
    skills: '',
    lookingFor: '',
    bio: '',
    contactInfo: ''
  });

  const handleCreateRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.eventName) return;

    const newReq: TeammateRequest = {
      id: `team-${Date.now()}`,
      name: formData.name,
      role: formData.role || 'Developer',
      university: formData.university || 'Tech University',
      avatar: formData.avatar,
      eventName: formData.eventName,
      skills: formData.skills.split(',').map((s) => s.trim()).filter(Boolean),
      lookingFor: formData.lookingFor.split(',').map((s) => s.trim()).filter(Boolean),
      bio: formData.bio,
      contactInfo: formData.contactInfo || 'discord: @hackbuilder',
      postedDate: 'Just now'
    };

    saveTeammateRequest(newReq);
    setRequests(getTeammateRequests());
    setPostModalOpen(false);
    setFormData({
      name: '',
      role: '',
      university: '',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
      eventName: '',
      skills: '',
      lookingFor: '',
      bio: '',
      contactInfo: ''
    });
  };

  const filteredRequests = requests.filter((req) => {
    const q = searchTerm.toLowerCase().trim();
    if (!q) return true;
    return (
      req.name.toLowerCase().includes(q) ||
      req.eventName.toLowerCase().includes(q) ||
      req.role.toLowerCase().includes(q) ||
      req.skills.some((s) => s.toLowerCase().includes(q)) ||
      req.lookingFor.some((l) => l.toLowerCase().includes(q))
    );
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-[#334155]/60">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-purple-500/15 text-[#c084fc] border border-purple-500/30">
            <Users className="w-3.5 h-3.5 text-[#a78bfa]" />
            <span>Community Teammate Matching</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Find Teammates
          </h1>
          <p className="text-sm text-[#94a3b8] leading-relaxed max-w-xl">
            Connect with talented software engineers, product designers, and researchers building winning hackathon projects.
          </p>
        </div>

        <button
          onClick={() => setPostModalOpen(true)}
          className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-xs sm:text-sm font-bold transition-all shadow-lg shadow-purple-600/30 active:scale-95 shrink-0"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Post Teammate Request</span>
        </button>
      </div>

      {/* Search Input */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-[#94a3b8]" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by skill (e.g. React, Python, UI/UX, AI, Blockchain) or event name..."
            className="w-full pl-10 pr-4 py-2.5 text-sm rounded-xl bg-[#172033] border border-[#334155] text-white placeholder-[#94a3b8] focus:outline-none focus:border-[#7c3aed]"
          />
        </div>
        <span className="text-xs text-[#94a3b8] shrink-0 font-medium">
          Showing {filteredRequests.length} builder profiles
        </span>
      </div>

      {/* Teammate Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredRequests.map((req) => (
          <div
            key={req.id}
            className="flex flex-col h-full rounded-2xl bg-[#172033]/80 border border-[#334155] p-6 hover:border-[#7c3aed]/50 hover:shadow-xl hover:shadow-purple-950/20 transition-all group"
          >
            {/* Top User Info */}
            <div className="flex items-start gap-3.5 mb-4">
              <img
                src={req.avatar}
                alt={req.name}
                referrerPolicy="no-referrer"
                className="w-12 h-12 rounded-xl object-cover border border-[#334155] shrink-0"
              />
              <div className="overflow-hidden">
                <h3 className="text-base font-bold text-white group-hover:text-[#a78bfa] transition-colors truncate">
                  {req.name}
                </h3>
                <div className="flex items-center gap-1.5 text-xs text-[#94a3b8] mt-0.5">
                  <GraduationCap className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span className="truncate">{req.role} • {req.university}</span>
                </div>
              </div>
            </div>

            {/* Event Tag */}
            <div className="p-2.5 rounded-xl bg-[#1e293b] border border-[#334155] text-xs font-semibold text-cyan-300 flex items-center gap-2 mb-3">
              <Calendar className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span className="truncate">For: {req.eventName}</span>
            </div>

            {/* Bio */}
            <p className="text-xs text-[#cbd5e1] leading-relaxed line-clamp-2 mb-4">
              "{req.bio}"
            </p>

            {/* Skills */}
            <div className="space-y-1.5 mb-3">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#94a3b8] block">
                Proficiencies:
              </span>
              <div className="flex items-center gap-1.5 flex-wrap">
                {req.skills.map((skill) => (
                  <span
                    key={skill}
                    className="text-[11px] px-2 py-0.5 rounded-md bg-[#0f172a] text-slate-300 border border-[#334155]"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            {/* Looking For */}
            <div className="space-y-1.5 mb-5 mt-auto">
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 block">
                Seeking Teammates With:
              </span>
              <div className="flex items-center gap-1.5 flex-wrap">
                {req.lookingFor.map((item) => (
                  <span
                    key={item}
                    className="text-[11px] px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-300 border border-amber-500/30"
                  >
                    + {item}
                  </span>
                ))}
              </div>
            </div>

            {/* Connect Button */}
            <button
              onClick={() => {
                setConnectModalRequest(req);
                setConnectMessageSent(false);
              }}
              className="w-full py-2 px-4 rounded-xl bg-[#1e293b] hover:bg-[#7c3aed] text-slate-200 hover:text-white text-xs font-semibold border border-[#334155] hover:border-[#7c3aed] transition-all flex items-center justify-center gap-2"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Connect</span>
            </button>
          </div>
        ))}
      </div>

      {/* Post Teammate Request Modal */}
      <Modal
        isOpen={postModalOpen}
        onClose={() => setPostModalOpen(false)}
        title="Post Teammate Request"
        maxWidth="lg"
      >
        <form onSubmit={handleCreateRequest} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Your Full Name *</label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g. Alex Rivera"
                className="w-full px-3 py-2 rounded-xl bg-[#0f172a] border border-[#334155] text-white focus:outline-none focus:border-[#7c3aed]"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Role / Year</label>
              <input
                type="text"
                value={formData.role}
                onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                placeholder="e.g. 3rd Year CS Student"
                className="w-full px-3 py-2 rounded-xl bg-[#0f172a] border border-[#334155] text-white focus:outline-none focus:border-[#7c3aed]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">University / Organization</label>
              <input
                type="text"
                value={formData.university}
                onChange={(e) => setFormData({ ...formData, university: e.target.value })}
                placeholder="e.g. Stanford University"
                className="w-full px-3 py-2 rounded-xl bg-[#0f172a] border border-[#334155] text-white focus:outline-none focus:border-[#7c3aed]"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Target Event *</label>
              <input
                type="text"
                required
                value={formData.eventName}
                onChange={(e) => setFormData({ ...formData, eventName: e.target.value })}
                placeholder="e.g. Global AI Hackathon 2026"
                className="w-full px-3 py-2 rounded-xl bg-[#0f172a] border border-[#334155] text-white focus:outline-none focus:border-[#7c3aed]"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Your Skills (comma separated)</label>
            <input
              type="text"
              value={formData.skills}
              onChange={(e) => setFormData({ ...formData, skills: e.target.value })}
              placeholder="React, TypeScript, Python, FastAPI, Tailwind"
              className="w-full px-3 py-2 rounded-xl bg-[#0f172a] border border-[#334155] text-white focus:outline-none focus:border-[#7c3aed]"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Looking For (comma separated)</label>
            <input
              type="text"
              value={formData.lookingFor}
              onChange={(e) => setFormData({ ...formData, lookingFor: e.target.value })}
              placeholder="UI/UX Designer, Smart Contract Dev, Backend Engineer"
              className="w-full px-3 py-2 rounded-xl bg-[#0f172a] border border-[#334155] text-white focus:outline-none focus:border-[#7c3aed]"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Short Pitch / Bio</label>
            <textarea
              rows={3}
              value={formData.bio}
              onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
              placeholder="Brief description of what you are building and what kind of team dynamic you thrive in..."
              className="w-full px-3 py-2 rounded-xl bg-[#0f172a] border border-[#334155] text-white focus:outline-none focus:border-[#7c3aed]"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Contact Handle (Discord, Email, or LinkedIn)</label>
            <input
              type="text"
              value={formData.contactInfo}
              onChange={(e) => setFormData({ ...formData, contactInfo: e.target.value })}
              placeholder="discord: @username or email@domain.com"
              className="w-full px-3 py-2 rounded-xl bg-[#0f172a] border border-[#334155] text-white focus:outline-none focus:border-[#7c3aed]"
            />
          </div>

          <div className="pt-3 border-t border-[#334155] flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setPostModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-[#1e293b] text-slate-300 font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-[#7c3aed] text-white font-bold hover:bg-[#6d28d9]"
            >
              Post Request
            </button>
          </div>
        </form>
      </Modal>

      {/* Connect Modal */}
      {connectModalRequest && (
        <Modal
          isOpen={Boolean(connectModalRequest)}
          onClose={() => setConnectModalRequest(null)}
          title={`Connect with ${connectModalRequest.name}`}
        >
          <div className="space-y-4 text-xs">
            <div className="flex items-center gap-3 p-3 rounded-xl bg-[#1e293b] border border-[#334155]">
              <img
                src={connectModalRequest.avatar}
                alt={connectModalRequest.name}
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-full object-cover"
              />
              <div>
                <h4 className="font-bold text-white text-sm">{connectModalRequest.name}</h4>
                <p className="text-cyan-300">{connectModalRequest.eventName}</p>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-black/40 border border-[#334155] space-y-1">
              <span className="text-[#94a3b8] block">Direct Contact Handle:</span>
              <span className="text-white font-mono font-bold text-sm select-all">
                {connectModalRequest.contactInfo || 'discord: @hackbuilder'}
              </span>
            </div>

            {connectMessageSent ? (
              <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                <span>Teammate invitation request sent to {connectModalRequest.name}!</span>
              </div>
            ) : (
              <div className="space-y-2">
                <label className="text-slate-300 font-semibold block">
                  Send a quick introduction message:
                </label>
                <textarea
                  rows={3}
                  defaultValue={`Hey ${connectModalRequest.name}, I saw your request for ${connectModalRequest.eventName} on HackFinder and would love to team up!`}
                  className="w-full p-2.5 rounded-xl bg-[#0f172a] border border-[#334155] text-white focus:outline-none focus:border-[#7c3aed]"
                />
                <button
                  onClick={() => setConnectMessageSent(true)}
                  className="w-full py-2.5 rounded-xl bg-[#7c3aed] hover:bg-[#6d28d9] text-white font-bold flex items-center justify-center gap-2"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send Teammate Request</span>
                </button>
              </div>
            )}
          </div>
        </Modal>
      )}

    </div>
  );
};
