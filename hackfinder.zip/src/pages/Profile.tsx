import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  User,
  Mail,
  GraduationCap,
  Calendar,
  Bookmark,
  Sparkles,
  Edit3,
  CheckCircle,
  ExternalLink,
  PlusCircle,
  Trophy,
  Github,
  Linkedin
} from 'lucide-react';
import { getUserProfile, saveUserProfile, getSavedEventIds, getAllEvents } from '../utils/storage';
import { UserProfile } from '../types';
import { Modal } from '../components/Modal';
import { EventCard } from '../components/EventCard';

export const Profile: React.FC = () => {
  const [profile, setProfile] = useState<UserProfile>(() => getUserProfile());
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'saved' | 'posted'>('saved');

  const [editForm, setEditForm] = useState({
    name: profile.name,
    email: profile.email,
    university: profile.university,
    year: profile.year,
    avatar: profile.avatar,
    bio: profile.bio,
    skills: profile.skills.join(', '),
    interests: profile.interests.join(', '),
    github: profile.github || '',
    linkedin: profile.linkedin || ''
  });

  const allEvents = getAllEvents();
  const savedIds = getSavedEventIds();
  const savedEvents = allEvents.filter((e) => savedIds.includes(e.id));
  const userPostedEvents = allEvents.filter((e) => e.id.startsWith('user-event-'));

  const handleProfileSave = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: UserProfile = {
      ...profile,
      name: editForm.name,
      email: editForm.email,
      university: editForm.university,
      year: editForm.year,
      avatar: editForm.avatar,
      bio: editForm.bio,
      skills: editForm.skills.split(',').map((s) => s.trim()).filter(Boolean),
      interests: editForm.interests.split(',').map((s) => s.trim()).filter(Boolean),
      github: editForm.github,
      linkedin: editForm.linkedin
    };

    saveUserProfile(updated);
    setProfile(updated);
    setEditModalOpen(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-10">
      
      {/* Profile Overview Card */}
      <div className="p-6 sm:p-10 rounded-3xl bg-[#172033]/90 border border-[#334155] shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="flex items-center gap-5">
            <div className="relative">
              <img
                src={profile.avatar}
                alt={profile.name}
                referrerPolicy="no-referrer"
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border-2 border-[#7c3aed] shadow-lg shadow-purple-950/50"
              />
              <span className="absolute -bottom-1 -right-1 w-5 h-5 bg-emerald-500 border-2 border-[#172033] rounded-full" title="Online" />
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  {profile.name}
                </h1>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#7c3aed]/20 text-[#c084fc] border border-[#7c3aed]/40">
                  BUILDER PRO
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs sm:text-sm text-[#94a3b8]">
                <GraduationCap className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>{profile.year} • {profile.university}</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-[#64748b]">
                <Mail className="w-3.5 h-3.5" />
                <span>{profile.email}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setEditModalOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-[#1e293b] hover:bg-[#334155] text-slate-200 text-xs font-semibold border border-[#334155] transition-colors flex items-center gap-2"
            >
              <Edit3 className="w-4 h-4 text-[#a78bfa]" />
              <span>Edit Profile</span>
            </button>
            <Link
              to="/post-event"
              className="px-4 py-2.5 rounded-xl bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-xs font-semibold shadow-md shadow-purple-600/30 flex items-center gap-1.5"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Host Event</span>
            </Link>
          </div>
        </div>

        {/* Bio */}
        <p className="text-xs sm:text-sm text-[#cbd5e1] leading-relaxed max-w-3xl pt-2 border-t border-[#334155]/60">
          "{profile.bio}"
        </p>

        {/* Skills & Interests Chips */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          <div className="space-y-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#94a3b8]">
              Verified Tech Skills:
            </span>
            <div className="flex items-center gap-1.5 flex-wrap">
              {profile.skills.map((skill) => (
                <span
                  key={skill}
                  className="text-xs px-2.5 py-1 rounded-lg bg-[#1e293b] text-slate-200 border border-[#334155]"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-cyan-400">
              Passionate Interests:
            </span>
            <div className="flex items-center gap-1.5 flex-wrap">
              {profile.interests.map((interest) => (
                <span
                  key={interest}
                  className="text-xs px-2.5 py-1 rounded-lg bg-cyan-500/10 text-cyan-300 border border-cyan-500/30"
                >
                  ★ {interest}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Quick Stats Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-[#334155]/60 text-center">
          <div className="p-3 rounded-xl bg-[#1e293b]/60 border border-[#334155]">
            <span className="text-lg font-bold text-white block">{savedEvents.length}</span>
            <span className="text-[11px] text-[#94a3b8]">Saved Events</span>
          </div>
          <div className="p-3 rounded-xl bg-[#1e293b]/60 border border-[#334155]">
            <span className="text-lg font-bold text-cyan-300 block">{userPostedEvents.length}</span>
            <span className="text-[11px] text-[#94a3b8]">Events Hosted</span>
          </div>
          <div className="p-3 rounded-xl bg-[#1e293b]/60 border border-[#334155]">
            <span className="text-lg font-bold text-purple-300 block">4</span>
            <span className="text-[11px] text-[#94a3b8]">Hackathons Won</span>
          </div>
          <div className="p-3 rounded-xl bg-[#1e293b]/60 border border-[#334155]">
            <span className="text-lg font-bold text-amber-300 block">Top 5%</span>
            <span className="text-[11px] text-[#94a3b8]">Builder Rank</span>
          </div>
        </div>
      </div>

      {/* Tabs Row (Saved vs Posted Events) */}
      <div className="space-y-6">
        <div className="flex items-center gap-3 border-b border-[#334155] pb-2">
          <button
            onClick={() => setActiveTab('saved')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
              activeTab === 'saved'
                ? 'bg-[#7c3aed] text-white shadow-md shadow-purple-600/30'
                : 'text-[#94a3b8] hover:text-white hover:bg-[#172033]'
            }`}
          >
            <Bookmark className="w-4 h-4" />
            <span>My Bookmarks ({savedEvents.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('posted')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
              activeTab === 'posted'
                ? 'bg-[#7c3aed] text-white shadow-md shadow-purple-600/30'
                : 'text-[#94a3b8] hover:text-white hover:bg-[#172033]'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>My Hosted Listings ({userPostedEvents.length})</span>
          </button>
        </div>

        {/* Tab Content */}
        {activeTab === 'saved' ? (
          savedEvents.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {savedEvents.map((event) => (
                <EventCard key={event.id} event={event} />
              ))}
            </div>
          ) : (
            <div className="p-10 text-center rounded-2xl bg-[#172033]/60 border border-[#334155] max-w-md mx-auto space-y-3">
              <Bookmark className="w-8 h-8 text-[#94a3b8] mx-auto" />
              <h3 className="text-base font-bold text-white">No saved events yet</h3>
              <p className="text-xs text-[#94a3b8]">Explore the catalog to bookmark upcoming hackathons and events.</p>
              <Link to="/events" className="inline-block px-4 py-2 rounded-xl bg-[#7c3aed] text-white text-xs font-semibold">
                Explore Events
              </Link>
            </div>
          )
        ) : userPostedEvents.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {userPostedEvents.map((event) => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        ) : (
          <div className="p-10 text-center rounded-2xl bg-[#172033]/60 border border-[#334155] max-w-md mx-auto space-y-3">
            <PlusCircle className="w-8 h-8 text-[#94a3b8] mx-auto" />
            <h3 className="text-base font-bold text-white">No hosted events yet</h3>
            <p className="text-xs text-[#94a3b8]">Host your first hackathon or technical meetup on HackFinder!</p>
            <Link to="/post-event" className="inline-block px-4 py-2 rounded-xl bg-[#7c3aed] text-white text-xs font-semibold">
              Create Event Listing
            </Link>
          </div>
        )}
      </div>

      {/* Edit Profile Modal */}
      <Modal
        isOpen={editModalOpen}
        onClose={() => setEditModalOpen(false)}
        title="Edit Profile Information"
        maxWidth="lg"
      >
        <form onSubmit={handleProfileSave} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Full Name</label>
              <input
                type="text"
                required
                value={editForm.name}
                onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-[#0f172a] border border-[#334155] text-white focus:outline-none focus:border-[#7c3aed]"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Email</label>
              <input
                type="email"
                required
                value={editForm.email}
                onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-[#0f172a] border border-[#334155] text-white focus:outline-none focus:border-[#7c3aed]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">University / Organization</label>
              <input
                type="text"
                value={editForm.university}
                onChange={(e) => setEditForm({ ...editForm, university: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-[#0f172a] border border-[#334155] text-white focus:outline-none focus:border-[#7c3aed]"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Academic Year / Role</label>
              <input
                type="text"
                value={editForm.year}
                onChange={(e) => setEditForm({ ...editForm, year: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-[#0f172a] border border-[#334155] text-white focus:outline-none focus:border-[#7c3aed]"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Avatar Image URL</label>
            <input
              type="url"
              value={editForm.avatar}
              onChange={(e) => setEditForm({ ...editForm, avatar: e.target.value })}
              className="w-full px-3 py-2 rounded-xl bg-[#0f172a] border border-[#334155] text-white focus:outline-none focus:border-[#7c3aed]"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Bio / Headline</label>
            <textarea
              rows={3}
              value={editForm.bio}
              onChange={(e) => setEditForm({ ...editForm, bio: e.target.value })}
              className="w-full px-3 py-2 rounded-xl bg-[#0f172a] border border-[#334155] text-white focus:outline-none focus:border-[#7c3aed]"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Skills (comma separated)</label>
            <input
              type="text"
              value={editForm.skills}
              onChange={(e) => setEditForm({ ...editForm, skills: e.target.value })}
              className="w-full px-3 py-2 rounded-xl bg-[#0f172a] border border-[#334155] text-white focus:outline-none focus:border-[#7c3aed]"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Interests (comma separated)</label>
            <input
              type="text"
              value={editForm.interests}
              onChange={(e) => setEditForm({ ...editForm, interests: e.target.value })}
              className="w-full px-3 py-2 rounded-xl bg-[#0f172a] border border-[#334155] text-white focus:outline-none focus:border-[#7c3aed]"
            />
          </div>

          <div className="pt-3 border-t border-[#334155] flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setEditModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-[#1e293b] text-slate-300 font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-[#7c3aed] text-white font-bold hover:bg-[#6d28d9]"
            >
              Save Profile
            </button>
          </div>
        </form>
      </Modal>

    </div>
  );
};
