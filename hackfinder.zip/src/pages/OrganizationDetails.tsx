import React from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  Building2,
  CheckCircle,
  MapPin,
  Globe,
  ArrowLeft,
  Calendar,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { INITIAL_ORGANIZATIONS } from '../data/events';
import { getAllEvents } from '../utils/storage';
import { EventCard } from '../components/EventCard';

export const OrganizationDetails: React.FC = () => {
  const { name } = useParams<{ name: string }>();
  const allEvents = getAllEvents();

  // Find organization by slug or lowercase name match
  const org = INITIAL_ORGANIZATIONS.find(
    (o) =>
      o.slug === name ||
      o.name.toLowerCase().replace(/\s+/g, '-') === name ||
      o.name.toLowerCase() === name?.toLowerCase()
  );

  if (!org) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-2xl font-bold text-white">Organization Not Found</h2>
        <p className="text-sm text-[#94a3b8]">
          We couldn't find the organization you requested.
        </p>
        <Link
          to="/organizations"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#7c3aed] text-white text-sm font-semibold"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to All Organizations</span>
        </Link>
      </div>
    );
  }

  // Find all events organized by this organization
  const orgEvents = allEvents.filter(
    (e) => e.organization.toLowerCase() === org.name.toLowerCase()
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-12">
      
      {/* Back button */}
      <div>
        <Link
          to="/organizations"
          className="inline-flex items-center gap-2 text-xs sm:text-sm font-medium text-[#94a3b8] hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Organizations</span>
        </Link>
      </div>

      {/* Organization Hero Profile Card */}
      <div className="p-6 sm:p-10 rounded-3xl bg-[#172033]/90 border border-[#334155] shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="flex items-center gap-5">
            <div className="w-20 h-20 rounded-2xl bg-slate-900 border border-[#334155] overflow-hidden p-1 flex items-center justify-center shrink-0 shadow-inner">
              <img
                src={org.logo}
                alt={org.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover rounded-xl"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  {org.name}
                </h1>
                {org.verified && (
                  <CheckCircle className="w-5 h-5 text-cyan-400" title="Verified Organizer" />
                )}
              </div>
              <p className="text-xs sm:text-sm text-cyan-300 font-semibold mt-1">
                {org.domains.join(' • ')}
              </p>
              <div className="flex items-center gap-4 text-xs text-[#94a3b8] mt-2">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-rose-400" />
                  {org.location}
                </span>
                <span className="flex items-center gap-1 text-slate-300">
                  <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                  {orgEvents.length || org.eventsCount} Events Listed
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <a
              href={org.website}
              target="_blank"
              rel="noreferrer"
              className="px-5 py-2.5 rounded-xl bg-[#1e293b] hover:bg-[#334155] text-slate-200 text-xs font-semibold border border-[#334155] transition-colors flex items-center gap-1.5"
            >
              <span>Visit Website</span>
              <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
            </a>
          </div>
        </div>

        <p className="text-sm text-[#cbd5e1] leading-relaxed max-w-3xl pt-2 border-t border-[#334155]/60">
          {org.description}
        </p>
      </div>

      {/* Events hosted by this org */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-white tracking-tight">
              Upcoming & Active Opportunities
            </h2>
            <p className="text-xs sm:text-sm text-[#94a3b8] mt-1">
              Official initiatives and programs hosted by {org.name}.
            </p>
          </div>
          <span className="text-xs font-semibold px-3 py-1 rounded-full bg-[#1e293b] text-slate-300 border border-[#334155]">
            {orgEvents.length} active
          </span>
        </div>

        {orgEvents.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {orgEvents.map((event) => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        ) : (
          <div className="p-12 text-center rounded-2xl bg-[#172033]/60 border border-[#334155] max-w-md mx-auto space-y-3">
            <Calendar className="w-8 h-8 text-[#94a3b8] mx-auto" />
            <h3 className="text-base font-bold text-white">No active listings currently</h3>
            <p className="text-xs text-[#94a3b8]">
              Stay tuned! New hackathons and conferences from this organization are posted frequently.
            </p>
          </div>
        )}
      </div>

    </div>
  );
};
