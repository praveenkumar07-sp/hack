export type EventType =
  | 'hackathon'
  | 'conference'
  | 'symposium'
  | 'workshop'
  | 'certification'
  | 'fellowship'
  | 'pitch'
  | 'technical'
  | 'academic';

export type EventMode = 'Online' | 'Offline' | 'Hybrid';

export type AudienceLevel = 'School' | 'UG' | 'PG' | 'Professionals' | 'Open';

export type CostType = 'free' | 'paid' | 'scholarship';

export interface EventTimelineItem {
  stage: string;
  date: string;
  description?: string;
  status?: 'completed' | 'current' | 'upcoming';
}

export interface EventItem {
  id: string;
  type: EventType;
  title: string;
  organization: string;
  organizationLogo?: string;
  category: string;
  domains: string[];
  mode: EventMode;
  city?: string;
  country: string;
  startDate: string;
  endDate: string;
  registrationDeadline: string;
  prizeAmount: number;
  currency: string;
  costType: CostType;
  feeAmount?: number;
  audienceLevel?: AudienceLevel;
  featured: boolean;
  trending: boolean;
  verified: boolean;
  image: string;
  description: string;
  about?: string;
  tags?: string[];
  eligibility?: string;
  tracks?: string[];
  submissionType?: string;
  registrationUrl: string;
  timeline?: EventTimelineItem[];
  benefits?: string[];
  participantsCount?: number;
  viewsCount?: number;
  savedCount?: number;
  createdAt?: string;
}

export interface Organization {
  name: string;
  slug: string;
  logo: string;
  description: string;
  website: string;
  eventsCount: number;
  domains: string[];
  verified: boolean;
  location: string;
}

export interface TeammateRequest {
  id: string;
  name: string;
  avatar: string;
  role: string;
  eventTitle?: string;
  eventName?: string;
  university?: string;
  skills: string[];
  lookingFor: string[];
  availability?: string;
  bio: string;
  experienceLevel?: string;
  contactEmail?: string;
  contactInfo?: string;
  postedAt?: string;
  postedDate?: string;
}

export interface UserProfile {
  name: string;
  email: string;
  headline?: string;
  avatar: string;
  bio: string;
  university?: string;
  year?: string;
  interests: string[];
  careerGoals?: string[];
  skills: string[];
  savedEventsCount?: number;
  applicationsCount?: number;
  githubUrl?: string;
  linkedinUrl?: string;
  github?: string;
  linkedin?: string;
}
